#include "sites.h"


namespace sites
{

  rnd::uniform * site::draw = NULL;

  unsigned simple3D::sizex = 1;
  unsigned simple3D::sizey = 1;
  unsigned simple3D::sizez = 1;


  ostream& operator<<(ostream& os, const simple3D s)
    {
      os << "(" << s.x << "," << s.y << "," << s.z << ")"; 
      return os;
    }
  
}
