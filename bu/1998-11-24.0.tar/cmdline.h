/*  automatic code produced by gencom 0.0 on Tue Nov 24 14:00:34 1998

    inputfile: <cmdline.cmdl>
 */

#include <stdio.h>

class c_cmdln
{
 public:
  c_cmdln(int, char * argv[]);

  friend ostream& operator<<(ostream&, const c_cmdln&);  float J;
  int size;
  int iterations;
};

c_cmdln::c_cmdln(int argc, char *argv[])
{
  J = 0.1 ;
  size = 10 ;
  iterations = 50 ;
  for(int i = 1; i<argc; i++)
     {
     if(!memcmp("J",argv[i], 1)) sscanf(argv[i] + 1, "%f", &J);
     if(!memcmp("s",argv[i], 1)) sscanf(argv[i] + 1, "%d", &size);
     if(!memcmp("i",argv[i], 1)) sscanf(argv[i] + 1, "%d", &iterations);
     if(argv[i][0] == '?')
        {
        printf(" options:");
        }
     }
}

 ostream& operator<<(ostream& os, const c_cmdln& s)
   {
    os
 << "J = " << s.J << endl
 << "size = " << s.size << endl
 << "iterations = " << s.iterations << endl
    ;
    return os;
   }
