/* ------------------------------------------------------
   Ising Model 
   
   ------------------------------------------------------
*/    

#include "ising.h"
#include <astack.h>

// 
template <class floatt, class spintype, class sitetype> 
void isingmodel<floatt, spintype, sitetype>::summarize(ostream& os)
{
  os << sitetype::max() << " Ising model \n";
  os << "Jx = " << m_Jx << "  Jy = " << m_Jy << "\n";
  os << "B = " << m_B << "\n";
  os << "number of spins up: " << nup() << "\n";

}

/* ---------------------------
   Metropolis algoritme.
   'Ising Model'
   
   zie ook: Reif, F. - Fundamentals of Statistical and Thermal Physics 
                     - McGraw-Hill 1985
*/


template <class floatt, class spintype, class sitetype> 
void isingmodel<floatt, spintype, sitetype>::MetropolisIteration()
{ 
  static unsigned i; // static to prevent repeating of declaration (more efficient, hopefully)

  // chose random site (metropolis):
  i = m_draw.idraw(sitetype::size());  

  // calculate energy difference if we would flip it:
  static floatt DeltaE;    //static to prevent realocation
    
  DeltaE = -2 * *getat(i) * ( m_Jx * getsumnb(i) - m_B );
  
  // assign new value for this spin:

  if(DeltaE < 0) // if DeltaE > 0, we do nothing
    { 
      if(m_draw.draw()>=1.0/(1+exp(+2*DeltaE))) // misschien nog niet goed.
	{ 
	  setat(i,(*getat(i)==1 ? -1 : 1)); 
	}
    }

  m_nit++; // number of iterations
}

/* ------------------------------------------------------------------------
   Swendsen / Wang 
   bond algoritme
   
  zie ook Phys. Rev. Letters {\bf 58} (1987) 86

*/

template <class floatt, class spintype, class sitetype> 
void isingmodel<floatt, spintype, sitetype>::SwendsenWangIteration()
{
// not yet implemented
  /*
    There used to be an implementation which was recursive, but it doesn't fit in the schema now.
    
  */

}
/* ------------------------------------------------------------------------

   Wolff algorithm

   see also Phys. Rev. Letters {\bf 62} (1989) 361
  
 */

template <class floatt, class spintype, class sitetype> 
void isingmodel<floatt, spintype, sitetype>::WolffIteration()
{
  static sitetype i;
  static unsigned j;

  // chose random lattice site:  
  i = m_draw.idraw(sitetype::size());
  
  //flip it:
  getat(i)->flip();

  //We need a stack to put positions in.
  // Astack is a fast stack type, see astack.h  
  static Astack<sitetype> thestack;

  thestack.push(i); // we want to start with our start position on the stack, because it makes our loop simpler.   

   // !! Not yet fully optimized for efficiency.
  while(!thestack.empty())
    {
      i = thestack.top();
      thestack.pop();
      // looking at the neighbors
      //cout << "neighbors of " << sitetype(i) << endl;
      for(j = 0; j < sitetype::maxnb(); j++)      
	{
	  //cout << "checking " << sitetype(sitetype(i).nb(j)) << endl;
	  if(!(*getat(i.nb(j))
                == *getat(i)))
	    { 
	      // decide to add it to the stack or not:	  	      
	      if(m_draw.draw() < m_one_minus_exp) // with probability 1 - exp(-K)
		{ 
		  getat(sitetype(i).nb(j)) -> flip(); //  flip this neighbor
		  thestack.push(sitetype(i).nb(j));   //  and push it on the stack
		}
	    }
	} // for neighbors    
    } // while stack not empty
  m_nit++;
}// Wolff

/* --------------------------------------------------------------------
   Anisotropic Wolff algorithm

   It seems to me impossible to do it with the same code, so that's why I create it again 
   here..

 */

template <class floatt, class spintype, class sitetype> 
void isingmodel<floatt, spintype, sitetype>::AnisotropWolffIteration()
{


}//Anisotropic Wolff

/* -------------------------------------------------------------------
   MAIN

*/

int main(int argc, char *argv[])
{
 
  //isingmodel<float, spins::updown, sites::simple2D<15,15> > model(0.001);

  isingmodel<float, spins::updown, sites::anisotrop2D<15,float> > model(0.001);
  
  model.init(1);
  model.summarize();
  //cout << model;
  //model.MetropolisIteration();
  cout << model;
  cout << "doing 100 Wolff iterations" << endl;
  for(int i = 0; i<1000; i++)
    {
      //cout << "iteration #" << model.getnit() << endl;
      model.WolffIteration();
    }
  cout << model;
  model.summarize();
  return 0;
}
