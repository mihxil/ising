
#include "spintype.h"

namespace spins
{
ostream& operator<<(ostream& os, const updown s)
{	  
  os << ((s.value == -1) ? "-" : ((s.value == +1) ? "+" : "*") ); 
  return os;
}
}
