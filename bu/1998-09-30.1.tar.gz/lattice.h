#ifndef __LATTICE_H_
#define __LATTICE_H_

#include <cstddef>
#include <iostream>
#include "rnd.h"


template <class spin, class site> 
class lattice
{
  // data members:
 private: 
  spin * r;
 protected:
  //  site sizes; 
  size_t size;
  
 public:
  //constructor:
  lattice();

  //member functions
  void  setat(site& s, spin v)    { r[s()] = v;    }
  void  setat(unsigned i , spin v){ r[i] = v;      }
  spin* getat(site s) const       { return &r[s()];}  // returns pointer, such that we can change it in one operation and we don't have to copy it.
  spin* getat(unsigned i) const   { return &r[i];  }
  spin  getsumnb(unsigned i) const 
    {
      spin hulps(0);
      for(int j=0; j<site::maxnb(); j++)
	{
	  hulps += r[site(i).nb(j)];
	}
      return hulps;
    }
  void  init();
  void  init(spin);
  void  print() const;
  template <class s, class st> friend ostream& operator<<(ostream&, const lattice<s,st>);
  unsigned nup() const;

};

/*
  Implementation of this template-class probably should be in this header file,
  because the compiler cannot know for which types it should generate code.

  These _are not_ real implementations, of course. Because they are only compiled if 
   necessary.


 */


template <class spin, class site> lattice<spin,site>::lattice()
{
 size =  site::size();
 // sizes = N;
 r = new spin[size];
}

template <class spin, class site> void lattice<spin, site>::init()
// initialiseert het rooster r met willekeurige waarden.
{
  for(int i=0; i<size; i++) setat(i, spin::random());
  return;  
}

template <class spin, class site> void lattice<spin, site>::init(spin v)
// initialiseert het rooster r met v
{
  for(int i=0; i<size; i++)
      setat(i,v);
  return;
}

template <class spin, class site> void lattice<spin, site>::print() const
{
  for(int i=0; i<sx; i++)
    {
      for(int j=0; j<sy; j++)
	{
	  cout << getat(i,j); 
	}
      cout << "\n";
    }
  return;
}

template <class spin, class site> ostream& operator<<(ostream &os, const lattice<spin, site> l)
// This functions only works for 2 dimensional lattices. 
{
  for(int i=0; i<site::maxx(); i++)
    {
      for(int j=0; j<site::maxy(); j++)
	{
          site s(i,j);
	  os << *(l.getat(s)); 
	}
      os << "\n";
    }
  return os;

}


template <class spin, class site> unsigned  lattice<spin, site>::nup() const
{ 
  unsigned hulp=0;
  for(int i=0; i<site::size(); i++)
      hulp+= getat(i)->upvalue();
  return hulp;
}


#endif //__LATTICE_H_
