// lattice.cpp
// Implementation of the 'lattice type'

#include "lattice.h"
