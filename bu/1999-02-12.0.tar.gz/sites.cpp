#include "sites.h"


namespace sites
{

  rnd::uniform * site::draw = NULL;

  template <int n> int cnD<n>::siz[n];

  ostream& operator<<(ostream& os, const simple3D s)
    {
      os << "(" << s.x[0] << "," << s.x[1] << "," << s.x[2] << ")"; 
      return os;
    }
  
}
