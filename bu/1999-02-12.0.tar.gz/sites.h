// -*-C++-*-
#ifndef __SITES_H_
#define __SITES_H_

#include <string>
#include "rnd.h"

namespace sites // possible sitetypes
{
  
  // base class for sites:
class site
{
 public:
  virtual unsigned operator()() { return  0;}
  virtual string lprint() { return  "";}  
  static rnd::uniform* draw;
};

// This one is undoubtable less efficient, but it's handy to have it of course.
template <int n>
class cnD : public site
{
public:
  int x[n];
  static int siz[n];

   cnD(int i = 0)     
    {
      int in = i;
      for(int j = 0; j < n; j++)
	{ 
	  x[j] = in % siz[j];
	  in /= siz[j];
	}
    } 

  int index() const
    {
      int in = x[n-1]; 
      for(int i = n - 2; i >= 0; i--)
	{ 
	  in = siz[i] * in + x[i];
	} 
      return in;
    }

  operator int() const 
    { 
      return index();
    }
  unsigned operator()() const 
    { 
      return index();
    }  

  static int max() 
    {
      int h = 1;
      for(int i = 0; i < n; i++) h*= siz[i];
      return h;
    }

  static setsizei(int i, int x) 
    {
      siz[i] = x;
    }

  static int maxnb() { return 2 * n;}
  static cnD<n> random() { return draw->idraw(max()); } // returns random site.

  int nb(int i) const
    {
      return; 
    }
  
};


//--------------------------------------------------------


    
/* ---------------------------------------------------------------------------
   
   1D 

 */

class simple1D : public cnD<1>
{
public:
  simple1D(int n) : cnD<1>(n) {}  
  
  friend ostream& operator<<(ostream&, const simple1D &); 
  
  virtual string lprint() { return x[0] == siz[0]-1 ? "\n" : "";}
};
/*
ostream& operator<<(ostream& os, const simple1D& s)
{
 os << "(" << s.x[0] << ")"; 
 return os;
} 
*/



/* --------------------------------------------------------------------
class simple2D, is an example of which the lattice-class type can use for it sizes.

The idea is that if you want to create another type of lattice, you only need to redefine 
a new type for its sites, in which you should define at least the same memberfunctions.

 */
class simple2D : public cnD<2>
{    
 public:
  simple2D(int n) : cnD<2>(n) {}  
  
  friend ostream& operator<<(ostream&, const simple2D);  
  virtual string lprint()  { return x[0] == siz[0] - 1 ? "\n" : "";}
 
};

/*
ostream& operator<<(ostream& os, const simple2D s)
{
 os << "(" << s.x[0] << "," << s.x[1] << ")"; 
 return os;
}
*/

// 3D model
// template<unsigned sizex=0, unsigned sizey=0> 
//template <unsigned n>
class simple3D : public cnD<3>
{
public:
  simple3D(int n) : cnD<3>(n) {}  

  static setsize(int x, int y, int z)
    {
      setsizei(0, x);
      setsizei(1, y);
      setsizei(2, z);
    }

  virtual simple3D  nb(unsigned i) // index of neighbor i
  {


  }
  friend ostream& operator<<(ostream&, const simple3D); 
  
  virtual string lprint(){ return x[0] == siz[0]-1 ? (x[1] == siz[1]-1 ? "\n\n" : "\n") : "";}
 
};



/* -----------------------------------------------------------------------------------------
   Transverse sites.
   One of the coordinates is a floating point number

 */

template <int n>
class transverse : public cnD<n-1>
{
  float trans;
};


/*
template <unsigned sizex, class floatt>
class transverse1D : public simple2D<sizex>
{
  floatt y;
 public:
    
  transverse2D (unsigned xx = 0, floatt yy = 0) : simple1D<sizex>(xx) { y = yy; }
  transverse2D (simple1D<sizex> x) : simple1D<sizex>(x) { y = 0; }

  static transverse2D<sizex, floatt> random() { return transverse2D(draw->idraw(sizex), draw->draw()); }
  static transverse2D<sizex, floatt> max()    { return transverse2D(sizex, 1); } // returns the largest site.

  template <unsigned  sx, class f> 
  friend ostream& operator<<(ostream&, const transverse2D<sx,f>&);

  virtual string lprint() { return x == sizex-1 ? "\n" : "";}

  floatt gety(){ return y;}
};

template <unsigned  sizex, class floatt> 
ostream& operator<<(ostream& os, const transverse2D<sizex, floatt>& s)
{
 os << "(" << s.x << "," << s.y << ")"; 
 return os;
} 
*/

}// namespace sites
#endif // __SITES_H_
