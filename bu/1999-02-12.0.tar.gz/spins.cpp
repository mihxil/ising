
#include "spins.h"

namespace spins
{
ostream& operator<<(ostream& os, const updown s)
{	  
  os << ((s.value == -1) ? "-" : ((s.value == +1) ? "+" : "*") ); 
  //os << "/" << s.value << "/";
  return os;
}

rnd::uniform* spin::draw = NULL;

}
