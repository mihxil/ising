#include "ising.h"



