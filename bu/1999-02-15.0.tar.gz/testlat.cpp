
#include "sites.h"
#include "lattice.h"
#include <iostream>

main()
{
  
  sites::simple2D::setsizei(0,10);
  sites::simple2D::setsizei(1,12);
  lattice<sites::simple2D > l;
  cout << l;
  for(int i = 0; i< sites::simple2D::max(); i++)
    {
      cout <<  l.r[i] << endl;
    }

  for(int i = 0; i< sites::simple2D::maxnb(); i++)
    cout << *(l.r[25].nb[i]) << endl;


}
