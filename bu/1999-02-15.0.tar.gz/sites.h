// -*-C++-*-
#ifndef __SITES_H_
#define __SITES_H_

#include <string>
#include "rnd.h"
#include "spins.h"

namespace sites // possible sitetypes
{
  
  // base class for sites:
template <class spinT>
class site
{
 public:
  spinT spin;  
  typedef spinT spintype;
  virtual unsigned operator()() { return  0;}
  virtual const char * lprint() { return  "";}  
  static rnd::uniform* draw;
};

// This one is undoubtable less efficient, but it's handy to have it of course.
template <int n, class st = typename spins::updown >
class cnD : public site <st>
{
public:
  int x[n];         // if we have the neighbours, then it might be even not necessary to store the location
  cnD<n> * nb[2*n]; // pointers to the neighbours (should be filled from external)

  static int siz[n];
  //  static int maxindex; // to avoid to repition of calculation this

   cnD(int i = 0)     
    {
     setx(i);
    } 

  void setx(int i)
    {
      int in = i;
      for(int j = 0; j < n; j++)
      { 
	x[j] = in % siz[j];
	in  /= siz[j];
      }
    }

  int findnb(int i) // finds the index of a neighbor
    {
      int x1[n];         // copy
      for(int j = 0; i< n; i++) x1[j] = x[j];

      int dimension = i / 2; // in which dimension it is
      int plusormin = (i % 2) * 2 - 1; // +/- 1
      
      x1[dimension] += plusormin;
      x1[dimension] %= siz[dimension]; // periodic bounday conditions      

      // convert it to an index:
      int in = x1[n-1]; 
      for(int j = n - 2; j >= 0; j--)
	{ 
	  in = siz[j] * in + x1[j];
	} 
      return in;
      
    }

  int index() const
    {
      int in = x[n-1]; 
      for(int i = n - 2; i >= 0; i--)
	{ 
	  in = siz[i] * in + x[i];
	} 
      return in;
    }
  /*
  operator int() const 
    { 
      return index();
    }
  */
  unsigned operator()() const 
    { 
      return index();
    }  

  static int max() 
    {     
      int h = 1;
      for(int i = 0; i < n; i++) h*= siz[i];
      return h;
    }

  static setsizei(int i, int x) 
    {
      siz[i] = x;
    }

  static int maxnb() { return 2 * n;}
  static cnD<n> random() { return draw->idraw(max()); } // returns random site.

  template <int tn, class tst>
  friend ostream& operator<<(ostream&, const cnD<tn,tst> &);  
    
};

template <int n, class st>
ostream& operator<<(ostream& os, const cnD<n, st>& s)
{
  os << "(";
  for(int i = 0; i<n - 1; i++) os << s.x[i] << ",";
  os << s.x[n -1] <<  ")"; 
  return os;
}

//--------------------------------------------------------


    
/* ---------------------------------------------------------------------------
   
   1D 

 */

class simple1D : public cnD<1>
{
public:
  simple1D(int n = 0) : cnD<1>(n) {}  
  
  friend ostream& operator<<(ostream&, const simple1D &); 
  
  virtual const char * lprint() { return x[0] == siz[0]-1 ? "\n" : "";}
};
/*
ostream& operator<<(ostream& os, const simple1D& s)
{
 os << "(" << s.x[0] << ")"; 
 return os;
} 
*/



/* --------------------------------------------------------------------
class simple2D, is an example of which the lattice-class type can use for it sizes.

The idea is that if you want to create another type of lattice, you only need to redefine 
a new type for its sites, in which you should define at least the same memberfunctions.

 */
class simple2D : public cnD<2>
{    
 public:
  simple2D(int n = 0) : cnD<2>(n) {}  
  
  virtual const char * lprint()  { return x[0] == siz[0] - 1 ? "\n" : "";}
 
};



/*
// 3D model
// template<unsigned sizex=0, unsigned sizey=0> 
//template <unsigned n>
class simple3D : public cnD<3>
{
public:
  simple3D(int n) : cnD<3>(n) {}  

  static setsize(int x, int y, int z)
    {
      setsizei(0, x);
      setsizei(1, y);
      setsizei(2, z);
    }

  virtual simple3D  nb(unsigned i) // index of neighbor i
  {


  }
  friend ostream& operator<<(ostream&, const simple3D); 
  
  virtual string lprint(){ return x[0] == siz[0]-1 ? (x[1] == siz[1]-1 ? "\n\n" : "\n") : "";}
 
};



/* -----------------------------------------------------------------------------------------
   Transverse sites.
   One of the coordinates is a floating point number

 */

template <int n>
class transverse : public cnD<n-1>
{
  float trans;
};


/*
template <unsigned sizex, class floatt>
class transverse1D : public simple2D<sizex>
{
  floatt y;
 public:
    
  transverse2D (unsigned xx = 0, floatt yy = 0) : simple1D<sizex>(xx) { y = yy; }
  transverse2D (simple1D<sizex> x) : simple1D<sizex>(x) { y = 0; }

  static transverse2D<sizex, floatt> random() { return transverse2D(draw->idraw(sizex), draw->draw()); }
  static transverse2D<sizex, floatt> max()    { return transverse2D(sizex, 1); } // returns the largest site.

  template <unsigned  sx, class f> 
  friend ostream& operator<<(ostream&, const transverse2D<sx,f>&);

  virtual string lprint() { return x == sizex-1 ? "\n" : "";}

  floatt gety(){ return y;}
};

template <unsigned  sizex, class floatt> 
ostream& operator<<(ostream& os, const transverse2D<sizex, floatt>& s)
{
 os << "(" << s.x << "," << s.y << ")"; 
 return os;
} 
*/

}// namespace sites
#endif // __SITES_H_
