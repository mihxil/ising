#ifndef __SPINTYPE_H_
#define __SPINTYPE_H_

// MM 29 september 1998

#include <iostream.h>
#include <rnd.h>
#include <avl.h>
#include <avl.cpp> // For the template instantiations.

/* In this file the classes for an actual system under study are described.

   A system is described by two classes, one which describes the 'spin' on a
   lattice site, and one which describes the properties of such a site.

 */

namespace spins // possible spintypes
{

class updown
{
 private:
  signed char value;
 public:
  // constructor
  updown(signed char i=1) { value = i; }

  // how it counts
  unsigned upvalue() { return value == 1 ? 1 : 0; }

  // how to flip it  
  updown*  flip() { value = -value; /*can this be more efficient*/ return this;}

  // how to convert this spin to a float:
  operator float(){ return (float)value; }

  // how to make a random value:
  static updown random() { static rnd::uniform draw(-10); return (draw.idraw(2) == 0) ? -1 : 1;}
  
  // - operator
  updown   operator-() { return -value; } 
  void     operator+=(updown& s) { value +=s.value;}

  // how to print this spin:
  friend ostream& operator<<(ostream&, const updown);
};

class anisotropic
  {
  };
 

} // namespace spins

namespace sites // possible sitetypes
{

/* --------------------------------------------------------------------
class simple2D, is an example of which the lattice-class type can use for it sizes.

The idea is that if you want to create another type of lattice, you only need to redefine 
a new type for its sites, in which you should define at least the same memberfunctions.

May be it would be an idea to make this type not a template but a class, from which we only 
could derive children. 

 */
template<unsigned sizex=0, unsigned sizey=0> 
class simple2D
{
  unsigned x,y; // may be it's quicker not to store x, y byt x + y*sizex
 public:
  simple2D(unsigned xx, unsigned yy) { x = xx; y = yy;}
  simple2D(unsigned i = 0) { x = i % sizex; y = i / sizex; }
  unsigned operator()()  { return x + y*sizex; }
  static unsigned size() { return sizex * sizey; }
  static unsigned maxx() { return sizex; }
  static unsigned maxy() { return sizey; } 
  static unsigned maxnb(){ return 4;}  // number of neighbors
  simple2D<sizex, sizey> nb(unsigned i)              // index of neighbor i
  {
    switch(i)
    {
      case 0: return (x - 1 + sizex) % sizex +  y*sizex;
      case 1: return (x +1) % sizex +  y*sizex;
      case 2: return x + ((y - 1 + sizey) % sizey) * sizex;
      case 3: return x + ((y +1) % sizey) * sizex;
    }

  }
  static simple2D<sizex, sizey> max() { return simple2D(sizex, sizey); } // returns the largest site.

  template <unsigned  sx, unsigned sy> friend ostream& operator<<(ostream&, const simple2D<sx,sy>); 
 
};

template <unsigned  sizex, unsigned sizey> ostream& operator<<(ostream& os, const simple2D<sizex,sizey> s)
{
 os << "(" << s.x << "," << s.y << ")"; 
 return os;
}

/* ---------------------------------------------------------------------------
   
   2D anisotropic 

   Is more or less treated as a 1D model, with a Tree on every site.

 */

template <class floatt>
class interfacetype
{
  floatt location;   // where it is located
  int left;          // what spin is left from this interface
 public:
  interfacetype(floatt loc =0 , int lef =0) { locations = loc; left = lef; }
  // a few operators have to been overloaded for this type (it must be comparable to fit in a avl::Tree)
};

template <unsigned sizex, class floatt>
class anisotrop2D
{
 private:
  unsigned x;
  // avl::Tree<double> y;
 
 public:
  anisotrop2D(unsigned xx = 0, unsigned yy = 0 /*ignored*/) { x = xx;}
  
  unsigned operator()()  { return x;     }
  static unsigned size() { return sizex; }
  static unsigned maxx() { return sizex; }
  static unsigned maxy() { return 0;     } // not possible 
  static unsigned maxnb(){ return 2;}      // number of neighbors
  anisotrop2D<sizex, floatt> nb(unsigned i)   // index of neighbor i
  {
    switch(i)
    {
      case 0: return (x - 1 + sizex) % sizex;
      case 1: return (x +1) % sizex;
    }
  }

  static anisotrop2D<sizex, floatt> max() { return anisotrop2D(sizex); } // returns the largest site.

  template <unsigned  sx, class sy> friend ostream& operator<<(ostream&, const anisotrop2D<sx,sy>&); 
};

template <unsigned  sizex, class floatt> ostream& operator<<(ostream& os, const anisotrop2D<sizex,floatt>& s)
{
 os << "(" << s.x << ",floatt )"; 
 return os;
} 


}// namespace sites

#endif // __SPINTYPE_H_

