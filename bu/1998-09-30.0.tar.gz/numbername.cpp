#include <stdio.h>
#include <errno.h>
#include <string.h>
/* en dit? */
#define maxnumber 10000

int main(int argc, char * argv[])
{ 
  char filename[256];
  char format[256];
  int filenamearg = 0;
  int i;
  int onlynumber = 0;
  

  for(i = 1; i< argc; i++)
    { if(argv[i][0] == '-')
      {switch (argv[i][1])
	{ case 'n': onlynumber = 1; break;
	  case '?':   

 printf(" Numbername -- Michiel Meeuwissen 13-6-1998 \n\n"
           "usage:\n\n"
           "    %s [-n] [-?] [<file-mask>] \n\n"
	   "In which <file-mask> defines a file-name with a \n"
           "format specifier for an integer (0-%d) in it. \n"
           "This program returns a filename with the lowest unused \n"
           "value filled in.\n\n"
           "- The file-mask also can come from standard input \n"
           "- With the option -n only the found number is returned \n\n"
           "Example (to make a backup of your source with the makefile):\n\n"
	   "tar c $(SOURCE) | gzip > `echo bu/\\`date \"+%%Y%%m%%d\"\\`.%%d.tar.gz \n | numbername | tee backup`\n\n" 
           , argv[0], maxnumber); return 1;
 
	  default : printf("Unknown commandline parameter %s\n", argv[i]); return 1; 
	}
      } 
      else
	{ if(filenamearg) {printf("More then one file-mask\n"); return 1;}
	  filenamearg = i;
	}

    }
  if(!filenamearg) { scanf("%s", format); }
  else { strncpy(format, argv[filenamearg], 256);}

  i = 0;
  FILE * fp;

  do{
  sprintf(filename, format, i);
  fp = fopen(filename,"r");  
  if (!fp && errno == ENOENT) {
                                 if(onlynumber) printf("%d", i);
                                 else           printf("%s",filename); 
                                 break;
                              }  
  fclose(fp);
  i++;
  } while ( i<maxnumber );
  return 0;
     
    
}

