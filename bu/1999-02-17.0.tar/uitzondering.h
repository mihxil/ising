

#include <g++-2/stdexcept>
#include <string>

  class uitzondering : public exception
    { 
      string _wat;
    public:
      uitzondering(const string& what_arg){ _wat = what_arg;}  
      string wat() { return _wat;}
    };
