// -*-C++-*-
#ifndef __SPINTYPE_H_
#define __SPINTYPE_H_

// MM 15 october 1998

#include <iostream.h>
#include <rnd.h>
#include <avl.h>
#include <avl.cpp> // For the template instantiations.
#include "sites.h"

/* In this file the classes for an actual system under study are described.

   A system is described by two classes, one which describes the 'spin' on a
   lattice site, and one which describes the properties of such a site.


 */

namespace spins // possible spintypes
{

class spin
{
 public:  
  static rnd::uniform*  draw;

  typedef int  spinsum;  // this is the type of the number of summed spins.
  typedef spin* attype;

  virtual attype at(sites::site s) { return this; } 
  // virtual spinsum upvalue() const { return 0;}
  
};
 

class updown : public spin
{
 private:
  signed value;
 public:
  // constructor
  updown(signed i=1) { value = i; }

  // how it counts
  spinsum upvalue() const { return value == 1 ? 1 : 0; }

  // how to flip it  
  updown*  flip() { value = -value; return this; }

  // how to convert this spin to a float:
  //operator float() const{ return (float)value; }

  // how to make a random value:
   bool makerandom() { value = (draw->idraw(2) == 0) ? -1 : 1;}
  
  // - operator
  updown   operator-() { return -value; } 
  //void     operator+=(updown s) { value +=s.value;}
  bool operator==(updown s) { return value == s.value; }

  // how to print this spin:
  friend ostream& operator<<(ostream&, const updown);

  //signed  getvalue() { return value;}
};
/* --------------------------------------------------------------------------------


 */
template <class floatt>
class anisotropic;


// interfacetype: a help type, it can not be regarded as a spin.
template <class floatt>
class interfacetype
{
  floatt  location;   // where it is located
  
  typedef updown rightspin; // may it could be something else..
  rightspin  right;      // what spin is right from this interface
  bool       two;     // if this interface is a double interface (sign doesn't change on it)
                         // used for tempory interfaces.
public:
  interfacetype() {location = 0; right = 0; two = false; }
  interfacetype(floatt loc, rightspin r = 0, bool d = false) 
    {
      location = loc; right = r; two = d;

    }
  //  interfacetype(const interfacetype<floatt> &s) { location = s.location; right = s.right; }
  // a few operators have to be overloaded for this type (it must be comparable to fit in a avl::Tree)
  
  template <class f> 
  friend ostream& operator<<(ostream&, const interfacetype<f>&);

  bool operator<(const interfacetype<floatt> & i) const 
    {
      return location < i.location; 
    } 

  // it's better not to compare floatt on equalness.
  bool operator==(const interfacetype<floatt> & i) const 
    { 
      return location == i.location; 
    }
    

  template <class f>
  friend ostream& operator<<(ostream&, const anisotropic<f>& );
  
  floatt gety() { return location; }
  rightspin getspin() { return right; } 

  friend class anisotropic<floatt>;
};

template<class floatt>
ostream& operator<<(ostream& os , const interfacetype<floatt>& a)
{
  
  os << a.location; 
  return os;
}
//------------------------------------------------------

template <class floatt> 
class anisotropic : public spin, public avl::Tree<interfacetype<floatt> >
  {
    typedef floatt spinsum; // the number of spins up now of course can be a floatt.
    typedef interfacetype<floatt> interface;
    
    typedef typename interface::rightspin  attype;

    // avl::Tree<interface > * values; 

  public:
    // overload constructors
    anisotropic () : avl::Tree<interface>() {};
    anisotropic (interface * i) : avl::Tree<interface>(i) {};
    
    
    attype at(floatt y) 
      { 
	interface l;
	SSearch(interface(y));
	l = *GetSmaller();
	return l.right;	
     } 
    void  GetNearestInterfaces(float y, interface ** l, interface **h)
      {
	SSearch(interface(y));
	*l = GetSmaller();
        *h = GetBigger();
	return;
      }


    static const int maxcol = 120;

    spinsum upvalue() const 
      {
	spinsum hulp = 0;
	interface * f;
	interface * of;
        typename interface::rightspin cur;
	
	f = Lowest();
	while(f)
	  {
	    of = f;
	    cur = of->right;
	    f = Next();
	    if(f && cur.upvalue()) hulp += f->location - of->location;
	  }
	if(cur.upvalue()) hulp+= 1.0 - of->location;
        
	return hulp; 
      }// returns part which is up.
    //floatt getvalue() { return 1;}

    bool  makerandom() 
    { 
      // inserts on 0 a random interface
      interfacetype<floatt> * ri = new interface(0,(draw->idraw(2) == 0) ? -1 : 1);
      Insert(ri);      
      return true; 
    }


    template <class f>
    friend ostream& operator<<(ostream&, const anisotropic<f>&);
  };

template<class floatt>
ostream& operator<<(ostream& os , const anisotropic<floatt>& a)
{
  //const int maxcol = 150;
  int column = 0;

  //  os << a.upvalue();
  typename anisotropic<floatt>::interface * f;
  typename anisotropic<floatt>::interface * of;
  //  typename anisotropic<floatt>::spintype::rightspin cur;

  f = a.Lowest();    
  while(f)
    {      
      of = f;
      //cur = of->right;
      f = a.Next();
      if(f) 
         {
	   os << '|'; // write explicitily the interface, in this way we more easily remark bugs
	   // in principle interface always divide areas with different spin.
	   for(int i=1; i<  (f->location - of->location) * a.maxcol; i++) os << of->right;; 
	 }
    }
  os << '|';
  for(int i=1; i<  (1.0 - of->location) * a.maxcol; i++) os << of->right; 
  os << a.Count() << endl;

  return os;
};

 


} // namespace spins

#endif // __SPINTYPE_H_
