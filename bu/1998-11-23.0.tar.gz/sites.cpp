#include "sites.h"


namespace sites
{

  rnd::uniform * site::draw = NULL;

}
