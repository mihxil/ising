/*  automatic code produced by gencom 0.50 on Wed Feb 24 14:19:43 1999

    inputfile: <cmdline.cmdl>
 */

#ifndef __cmdline_cmdl__
#define __cmdline_cmdl__
#include <stdio.h>

class c_cmdln
{
 char * info;
 public:
  c_cmdln(int = 0, char * argv[] = NULL, char * _info = NULL);

  friend ostream& operator<<(ostream&, const c_cmdln&);
  float  K;
  int  sizex;
  int  sizey;
  int  sizez;
  float  sizea;
  int  iterations;
  int  averagei;
  int  averageQ;
  int  seed;
  int  ntoss;
};

c_cmdln::c_cmdln(int argc, char *argv[], char * _info)
{
   info = _info;
  char * gc_string;
   K = 0.22;
   sizex = 10;
   sizey = 10;
   sizez = 6;
   sizea = 10;
   iterations = 100;
   averagei = 10;
   averageQ = 10;
   seed = 5;
   ntoss = 100;
  for(int i = 1; i<argc; i++)
     {
      int recognized = 0;
      if(!memcmp("K",argv[i], 1)){ sscanf(argv[i] + 1, "%f", &K); recognized++;}
      if(!memcmp("sx",argv[i], 2)){ sscanf(argv[i] + 2, "%d", &sizex); recognized++;}
      if(!memcmp("sy",argv[i], 2)){ sscanf(argv[i] + 2, "%d", &sizey); recognized++;}
      if(!memcmp("sz",argv[i], 2)){ sscanf(argv[i] + 2, "%d", &sizez); recognized++;}
      if(!memcmp("sa",argv[i], 2)){ sscanf(argv[i] + 2, "%f", &sizea); recognized++;}
      if(!memcmp("i",argv[i], 1)){ sscanf(argv[i] + 1, "%d", &iterations); recognized++;}
      if(!memcmp("ni",argv[i], 2)){ sscanf(argv[i] + 2, "%d", &averagei); recognized++;}
      if(!memcmp("nq",argv[i], 2)){ sscanf(argv[i] + 2, "%d", &averageQ); recognized++;}
      if(!memcmp("seed",argv[i], 4)){ sscanf(argv[i] + 4, "%d", &seed); recognized++;}
      if(!memcmp("ntoss",argv[i], 5)){ sscanf(argv[i] + 5, "%d", &ntoss); recognized++;}
      if(argv[i][0] == 'h')
        {
        recognized++;
        if(info) printf("%s\n",info);
        printf("use:\n    %s [options] \n", argv[0]);
        printf("options:\n"); 
        printf(" K???     :(0.22) temperature\n");
        printf(" sx???    :(10) size in x direction\n");
        printf(" sy???    :(10) size in y direction\n");
        printf(" sz???    :(6) size in z direction\n");
        printf(" sa???    :(10) size in z direction for transverse model\n");
        printf(" i???     :(100) number of iterations between measurements\n");
        printf(" ni???    :(10) number of time it is done, to get an ensemble avarage for Q\n");
        printf(" nq???    :(10) number of time Q is calculated, to get an error estimation\n");
        printf(" seed???  :(5) random seed\n");
        printf(" ntoss??? :(100) number of times to iterate before the measurement starts\n");
        exit(0);
        }
      if(!recognized) { printf("Unrecognized commandline option %s (try 'h')\n", argv[i]);exit(1);}
      if(recognized > 1) { printf("**Dubious commandline option %s (this is a bug in sourcefile cmdline.cmdl)**\n", argv[i]);exit(1);}
     }
}

 ostream& operator<<(ostream& os, const c_cmdln& s)
   {
    os
    << "K = " << s.K << endl
    << "sizex = " << s.sizex << endl
    << "sizey = " << s.sizey << endl
    << "sizez = " << s.sizez << endl
    << "sizea = " << s.sizea << endl
    << "iterations = " << s.iterations << endl
    << "averagei = " << s.averagei << endl
    << "averageQ = " << s.averageQ << endl
    << "seed = " << s.seed << endl
    << "ntoss = " << s.ntoss << endl
    ;
    return os;
   }
#endif // __cmdline_cmdl__
