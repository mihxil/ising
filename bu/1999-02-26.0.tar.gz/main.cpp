/*
   february 1999 Michiel Meeuwissen


 */

#include "ising.h"
#include "cmdline.h"
#include "ising.cpp" // strange thing to do, but otherwise the template instantiations don't work.

/* -------------------------------------------------------------------	\
   MAIN									\

*/

int main(int argc, char *argv[])
{
    typedef double floattt;  
    c_cmdln cmdl(argc, argv, // reads the commandline parameters in 'cmdl'.
    "Ising programma -- Michiel Meeuwissen, december 1998"); 


    // We only use one random-generator.
    // The several classes all have a pointer to it. 
    // further, we make sure that the seed is always postive...
    // Take care about that, because it depends from the generator (should make something better for that)
    rnd::exponential draw(abs(cmdl.seed) + 1 );

    // copy a pointer to this random number generator to the classes
    spins::spin::draw = &draw;
    sites::sitet::draw = &draw;

    // How to write floating point numbers:
    cout.setf(ios::fixed, ios::floatfield); // default precision 6 digits
    // Stroustrup sais ios -> ios_base, but this isn't recognized by the current state of this compiler.

    // several examples (comment only one out)

    // set the size before we define our model (otherwise runtime error, because the model declares memory)

    /* 2D example
    sites::simple2D::setsizei(0,10);
    sites::simple2D::setsizei(1,10);
    
    isingmodel<float, sites::simple2D> model(&draw, cmdl.K);

    model.init();
    cout << model;
    for(int i = 0; i < cmdl.iterations; i++) model.WolffIteration();	  
    cout << "\n\n";
    cout << model;
    */

    // define the model:
   
    try
      {
	// simple 3D model
	/*
	typedef float Float;
	sites::simple3D::setsizei(0, cmdl.sizex);
	sites::simple3D::setsizei(1, cmdl.sizey);
	sites::simple3D::setsizei(2, cmdl.sizez);

	isingmodel<Float, sites::simple3D>  model(&draw, cmdl.K);
	
	//model.init();
	//model.summarize();  
	//cout << model; 
	
	 model.sizes(cout) << " Ising model  at K = " << cmdl.K << "  seed = " << cmdl.seed << endl;


	 //Before we start the real calculation we want to bring the model to an equilibrium:
	 model.init(); // set all spins to known positions:
	 //for(int i= 0; i < cmdl.ntoss; i++) model.WolffIteration();


	 Float sumM2 = 0;  
	 Float sumM4 = 0;     
	 Float tsumM2 = 0; // totalsum
	 Float tsumM4 = 0;
	 Float M, M2, Q, sumQ = 0 , sumQ2 =0;
	 unsigned nup;
	 
	 
	 for(int k = 0; k < cmdl.averageQ; k++)
	   {      
	     sumM2 = 0; 
	     sumM4 = 0;
	     for(int j = 0; j < cmdl.averagei; j++)
	       {
		 //model.init(); // set all spins to one direction, we might not want to do this everytime
		 
		 // loop to reach new equilibrium
		 
		 for(int i = 0; i < cmdl.iterations; i++) model.WolffIteration();	  
		 // Magnetisation:
		 M = (Float)2 * model.nup() - model.size();
		 M2 = M*M;
		 sumM2 += M2;
		 sumM4 += M2*M2;          
	       }
	     
	     tsumM2 += sumM2;
	     tsumM4 += sumM4;
	     Q = (Float)sumM2*sumM2 / (cmdl.averagei * sumM4); 
	     sumQ  += Q;
	     sumQ2 += Q*Q;
	   }
	 
	 //cout << "   <M^2> = " << (float)sumM2/cmdl.averagei 
	 //     << "\n <M^4> = " << (float)sumM4/cmdl.averagei
	 Q  = sumQ / cmdl.averageQ; // help to calculte dQ
	 Float dQ = sqrt(sumQ2 / (cmdl.averageQ) - Q*Q); // SDn-1 
	 Float realQ = (Float)tsumM2*tsumM2 / (cmdl.averagei * cmdl.averageQ *tsumM4); 
	 cout  << "    Q  = " << realQ << " +- " << dQ << endl;
	*/
	typedef float Float;
	typedef sites::transverse1D site;

	site::setsizei(0, cmdl.sizex);
	// site::setsizei(1, cmdl.sizey);
        site::setsize(cmdl.sizea);
	
	isingmodel<Float, site>  model(twolff, &draw, cmdl.K);
	
	model.init(1);
	model.summarize(cout);
	cout << "seed = " << cmdl.seed << endl;	
	cout << model; 
	model.Iteration();
	model.summarize(cout);
	cout << model;
	
      }
    catch (bad_alloc)
      {
	cerr << "ising: Not enough memory available\n";
      }
    catch (uitzondering e)
      {
	cerr << e.wat() << endl;
      }
    //model.AnisotropicWolffIteration();
    
  //model.summarize();
    //cout << model;
    return 0;
}
