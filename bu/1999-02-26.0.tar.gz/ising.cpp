
/* ------------------------------------------------------
   Ising Model 
   
   ------------------------------------------------------
*/
    
//#include <iostream>
#include "ising.h"
#include "spins.h"
#include "sites.h"
#include <astack.h>


// 
template <class floatt,  class sitetype> 
void  isingmodel<floatt, sitetype>::summarize(ostream& os)
{
  sizes(os) << " Ising model  at K = " << m_K << endl 
	    << "number of spins up: " << nup() << "\n";

}
/* ---------------------------
   Metropolis algoritme.
   'Ising Model'
   
   zie ook: Reif, F. - Fundamentals of Statistical and Thermal Physics 
                     - McGraw-Hill 1985
*/


template <class floatt, class sitetype> 
void isingmodel<floatt, sitetype>::MetropolisIteration()
{ 
  unsigned i;

  // chose random site (metropolis):
  i = m_draw->mdraw(sitetype::max());  

  // calculate energy difference if we would flip it:
  static floatt DeltaE;    //static to prevent realocation

  typename sitetype::spintype::spinsum sumnb = 0;
  //
  for(int j=0; j< sitetype::maxnb(); j++)
    {
      sumnb += r[i].nb[j]->spin;
    }
    
  DeltaE = -2 * r[i].spin * ( m_Jx * sumnb - m_B );
  
  // assign new value for this spin:

  if(DeltaE < 0) // if DeltaE x> 0, we do nothing
    { 
      if(m_draw->draw()>=1.0/(1+exp(+2*DeltaE))) // misschien nog niet goed.
	{ 
	  r[i].spin.flip();
	}
    }
 
  m_nit++; // number of iterations
}

/* ------------------------------------------------------------------------
   Swendsen / Wang 
   bond algoritme
   
  zie ook Phys. Rev. Letters {\bf 58} (1987) 86

*/

template <class floatt, class sitetype> 
void isingmodel<floatt, sitetype>::SwendsenWangIteration()
{
// not yet implemented
  /*
    There used to be an implementation which was recursive, but it doesn't fit in the schema now.
    
  */

}
/* ------------------------------------------------------------------------

   Wolff algorithm

   see also Phys. Rev. Letters {\bf 62} (1989) 361
  
 */

template <class floatt, class sitetype> 
void isingmodel<floatt,  sitetype>::WolffIteration()
{
  typename sitetype::pointer currentsite, neighbor;
  unsigned j;

  // chose random lattice site:  
  unsigned random = sitetype::random();
  currentsite = &(r[random]);
  
  //flip it:
  (currentsite->spin).flip();

  //We need a stack to put positions in.
  // Astack is a fast stack type, see astack.h  
  static Astack<typename sitetype::pointer> thestack;

  thestack.push(currentsite); // we want to start with our start position on the stack, because it makes our loop simpler.   

   // !! Not yet fully optimized for efficiency.
  while(!thestack.empty())
    {
      currentsite = thestack.top(); thestack.pop();
      // looking at the neighbors
      for(j = 0; j < sitetype::maxnb(); j++)      
	{
	  neighbor = currentsite->nb[j];
	  if(!((neighbor->spin) == (currentsite->spin)))
	    { 
	      // decide to add it to the stack or not:	  	      
	      if(m_draw->draw() < m_one_minus_exp) // with probability 1 - exp(-K)
		{ 
		  neighbor->spin.flip(); //  flip this neighbor		  
		  thestack.push(neighbor);   //  and push it on the stack
		}
	    }
	} // for neighbors    
    } // while stack not empty
  m_nit++; // count iterations (not really necessary)
}// Wolff

/* --------------------------------------------------------------------
   Anisotropic/Transverse Wolff algorithm

   It seems to me impossible to do it with the same code, so that's why I create it again 
   here..

 */
template <class floatt, class sitetype>
class area
{
public:
  area(typename sitetype::interface * s = NULL, typename sitetype::interface * b = NULL, const unsigned i_ = 0)
    {
      smaller = s;
      bigger = b;
      i = i_;
    }
  area(const area<floatt, sitetype>& a) { smaller = a.smaller; bigger = a.bigger; i = a.i; }

  typename sitetype::interface * smaller, * bigger;
  unsigned i;
};


template <class floatt, class sitetype> 
void isingmodel<floatt, sitetype>::TransverseWolffIteration()
{

  // We need a stack to put areas in.
  // Astack is a fast stack type, see astack.h  
  Astack<area<floatt, sitetype> > thestack; 

  // draw random position:
  // this can may be done more efficiently (with e.g. only one draw)
  sites::c_location<floatt>* i = new sites::c_location<floatt>  (m_draw,  sitetype::max(), sitetype::getsize());   // constructor is random

  
  typename sitetype::interface * smaller, * bigger;

   // get nearest interfaces:
  r[i->i].spin.SSearch(typename sitetype::interface(i->z));
  area<floatt, sitetype> ca(r[i->i].spin.GetSmaller(), r[i->i].spin.GetBigger(), i->i);
  // abreviation of 'current area'

  // We have to check on the boundaries.
  // boundary conditions:
  if(ca.smaller == &(r[i->i].spin.left))
    {
      r[i->i].spin.SSearchBiggest();
      ca.smaller = r[i->i].spin.GetSmaller();
      // if there were no interfaces, it is still the left-inteface, otherwise it's the most right real one
    }
  if(ca.bigger == &(r[i->i].spin.right))
    {
      r[i->i].spin.SSearchSmallest();
      ca.bigger = r[i->i].spin.GetBigger();
      // if there were no interfaces, it is still the right-one, otherwise it's the most left real one
    }

  // put it on the stack
  thestack.push(area<floatt, sitetype>(ca));
  
  while(!thestack.empty())
    {
      ca = thestack.top(); thestack.pop();      

      // a jump; an expontial distributed number:
      floatt jump = m_draw->edraw();
      
      floatt distl = i->z - smaller->gety(); // we always find a smaller one. (namely on zero)
      floatt distr = bigger->gety() - i->z;  // we also always find a bigger one. (namely on the other end)
      
      cout << "dist to left: " << distl << "    dist to right: " << distr << endl;

      if(jump > sitetype::getsize())
	{
	}
    }
  /*
      typename sitetype::interface::rightspin rs;
      rs = smaller->getspin();
      
      m_draw->setmean(m_exp_kx);
      //lower side:
      jump = 0.1; // (*m_draw)();     

      
      //r[i->i].spin.DumpTree(cout);  // debug

      // periodic boudary conditions:
      if(jump > i->z)

      if(jump > distl) // jumped over interface, remove interface
	{	  
          r[i->i].spin.DeleteSmaller();
	}
      else                // not jumped over it, add one.
	{
	  r[i->i].spin.Insert(new typename  sitetype::interface(i->z-jump, -rs));
	  i->z = i->z - jump;
	}
      // r[i->i].spin.DumpTree(cout);  // debug

      //higher side side (same things:
      jump = 0.1; // new random number
      if(jump >= distr) // jumped over nearest interface
	{
	  r[i->i].spin.DeleteBigger();
	}
      else                //
	{
	  r[i->i].spin.Insert(new typename sitetype::interface(i->z + jump, rs));
	  // hy = i->z + jump;
	}
      // r[i->i].spin.DumpTree(cout);  // debug

      // We now know in which area we should try to add interfaces in the 
      // other directions
  */
      /*
      m_draw->setmean(0.2);
      for(unsigned j = 0; j < sitetype::maxnb(); j++) 
	{
	  for(floatt ny = ly + (*m_draw)(); ny< hy; ny+= (*m_draw)())
	    {	
	      cout << r[i->i].nb[j]->spin.at(ny);
	      r[i->i].nb[j]->spin.Insert(new typename sitetype::interface(ny,0));

	    }
	}
      */
      //r[i->i].spin.DumpTree(cout);  // debug
            
    
 
  //Wolff iteration completed
  m_nit++;
  return;
}//Anisotropic Wolff
