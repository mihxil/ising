#ifndef _ISING_H__
#define _ISING_H__
#include "lattice.h"
#include "rnd.h"

/*

       
*/

typedef enum { metropolis, swendsenwang, wolff, twolff} iterationtype;

template <class floatt, class sitetype> 
class isingmodel : public lattice<sitetype>
{
 

  
  floatt           m_K, m_one_minus_exp;
  floatt  m_B, m_Jx, m_exp_kx;
  //  m_Kx, m_Ky, m_B, m_one_minus_exp, m_beta;
  unsigned         m_nit; // number of iterations
  rnd::exponential * m_draw; 
  
  void (isingmodel<floatt, sitetype>::*m_iteration)(void); // function used for iterations.  , neat idea, but it's going to give to much trouble.
  
 public:

  void Iteration() { (this->*m_iteration)(); }

  void MetropolisIteration();         // how to do one simple Metropolis iteration
  void SwendsenWangIteration();       // Swendsen-Wang (not implemented)
  void WolffIteration();              // Simple Wolff.
  void TransverseWolffIteration();    // Wolff for the Transverse Model.

  // constructor:
  isingmodel(iterationtype it, rnd::exponential * d, floatt K = 1) : lattice<sitetype> () 
    {
      m_draw = d;
      m_K = K;
      m_nit = 0;
      m_B = 0;
      m_one_minus_exp = 1 - exp(- 2*m_K);
      
      switch(it)
	{	  
	case metropolis:   m_iteration = &MetropolisIteration; break;
	case swendsenwang: m_iteration = &SwendsenWangIteration; break;
	case wolff:        m_iteration = &WolffIteration; break;
	case twolff:       m_iteration = &TransverseWolffIteration; break;
	default:           m_iteration = 0;
	}
    }
  
  
  //  void Iterate() { m_iteration(); } // for the time being I resign about this.

  void     summarize(ostream& os = cout);
  unsigned getnit() { return m_nit;}
  
};

#endif // #define _ISING_H__
