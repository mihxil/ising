// -*-C++-*-
#ifndef __SPINS_H_
#define __SPINS_H_

// MM 15 october 1998

#include <iostream.h>
#include <rnd.h>
#include <avl.h>
#include <avl.cpp> // For the template instantiations.
#include "uitzondering.h"

/* In this file the classes for an actual system under study are described.

   A system is described by two classes, one which describes the 'spin' on a
   lattice site, and one which describes the properties of such a site.


 */

namespace spins // possible spintypes
{
  
class spin
{
 public:  
  static rnd::uniform*  draw;
  
  typedef int  spinsum;  // this is the type of the number of summed spins.
  friend  spinsum  operator+=(spinsum s1, spin s) { throw uitzondering("+= operator not defined for this type");}
  spin*  flip() { throw uitzondering("flip-operator not defined for this type");}
  friend  spinsum  operator*(spinsum s1, spin s) { throw uitzondering("* operator not defined for this type");}
  bool operator==(spin s)  { throw uitzondering("== operator not defined for this type");}
};
 

class updown : public spin
{
 private:
  signed value;
 public:
  // constructor
  updown(signed i = 1) { value = i; }

  // how it counts
  spinsum upvalue() const { return value == 1 ? 1 : 0; }

  // how to flip it  
  updown*  flip() { value = -value; return this; }

  // how to convert this spin to a float:
  //operator float() const{ return (float)value; }

  // how to make a random value:
  bool makerandom(    ) { value = (draw->mdraw(2) == 0) ? -1 : 1; }
  bool makevalue(int i) { value = i<0 ? -1 : 1; }
  // how to set it a value:
  
  // - operator
  updown   operator-() { return -value; } 
  friend  spinsum  operator+=(spinsum s1, updown s) { s1 +=s.value;}
  bool operator==(updown s) { return value == s.value; }

  // how to print this spin:
  friend ostream& operator<<(ostream&, const updown);

  //signed  getvalue() { return value;}
};
/* --------------------------------------------------------------------------------


 */
template <class floatt>
class transverse;


// interfacetype: a help type, it can not be regarded as a spin.
template <class floatt>
class interfacetype
{
  floatt  location;   // where it is located
  
  typedef updown rightspin; // may it could be something else..
  rightspin  right;      // what spin is right from this interface
  bool       two;     // if this interface is a double interface (sign doesn't change on it)
                         // used for tempory interfaces, and for the interface on z=0
public:
  //  interfacetype() { location = 0; right = 0; two = false; } 
  interfacetype(floatt loc = 0, rightspin r = 0, bool d = false) 
    {
      location = loc; 
      right = r; 
      two = d;
    }
  //  interfacetype(const interfacetype<floatt> &s) { location = s.location; right = s.right; }
  // a few operators have to be overloaded for this type (it must be comparable to fit in a avl::Tree)
  
  template <class f> 
  friend ostream& operator<<(ostream&, const interfacetype<f>&);

  bool operator<(const interfacetype<floatt> & i) const 
    {
      return location < i.location; 
    } 

  // it's better not to compare floatt on equalness.
  // but we need it, because it is used in the avl-tree algorithm
  bool operator==(const interfacetype<floatt> & i) const 
    { 
      return location == i.location; 
    }
    
  template <class f>
  friend ostream& operator<<(ostream&, const transverse<f>& );
  
  floatt gety() { return location; }
  rightspin getspin() { return right; } 

  friend class transverse<floatt>;
};

template<class floatt>
ostream& operator<<(ostream& os , const interfacetype<floatt>& a)
{
  os << a.location; 
  return os;
}
//------------------------------------------------------

template <class floatt = float> 
class transverse : public spin, public avl::Tree<interfacetype<floatt> >
  {
    typedef floatt                spinsum; // the number of spins up now of course can be a floatt.
    typedef interfacetype<floatt> interface;
    
    typedef typename interface::rightspin  attype;

    static floatt  length;   // 'a3', all spins have the same length, therefore I made it static

  public:
    interfacetype<floatt> left, right; // interfaces on the left and right hand of the area, so we can easily find where they are.

    // avl::Tree<interface > * values; 


    // overload constructors
    transverse () : avl::Tree<interface>(), left(0,1,true), right(length,1,true)
    {
      Insert(&left);
      Insert(&right);      
    };
    transverse (interface * i) : avl::Tree<interface>(i) , left(0,1,true), right(length,1,true)
    {
      Insert(&left);
      Insert(&right);      

    };

    static void setlength(floatt x) 
    {
      length = x;     
    }
    static floatt getlength() { return length; }

    attype at(floatt y) 
      { 
	SSearch(interface(y));
	return GetSmaller()->right;
     } 
    /*
    void  GetNearestInterfaces(float y, interface ** l, interface **h)
      {
	SSearch(interface(y));
	*l = GetSmaller();
        *h = GetBigger();
	return;
      }
    */
    static const int maxcol = 2; // for drawing purposes, the ratio y/x of a character

    spinsum upvalue() const 
      {
	spinsum hulp = 0;
	interface * f;
	interface * of;
        typename interface::rightspin cur;
	
	f = Lowest();
	while(f)
	  {
	    of = f;
	    cur = of->right;
	    f = Next();
	    if(f && cur.upvalue()) hulp += f->location - of->location;
	  }
	if(cur.upvalue()) hulp+= length - of->location;
        
	return hulp; 
      }// returns part which is up.
    //floatt getvalue() { return 1;}

    bool  makerandom() 
    { 
      left.right  = (draw->mdraw(2) == 0 ? -1 : 1);
      right.right = left.right;
      return true; 
    }
    bool makevalue(int i)
    {
      left.right  = (i < 0 ? -1 : 1);
      right.right = left.right;
      return true;       
    }

    template <class f>
    friend ostream& operator<<(ostream&, const transverse<f>&);
  };



template<class floatt>
floatt transverse<floatt>::length = 1; // don't make it 0, because in that case the right interface won't be inserted


template<class floatt>
ostream& operator<<(ostream& os , const transverse<floatt>& a)
{
  

  //const int maxcol = 150;
  int column = 0;

  //  os << a.upvalue();
  typename transverse<floatt>::interface * f;
  typename transverse<floatt>::interface * of;
  //  typename anisotropic<floatt>::spintype::rightspin cur;

  f = a.Lowest();    
  while(f)
    {      
      of = f;
      //cur = of->right;
      f = a.Next();
      if(f) 
         {
	   os << '|'; // write explicitily the interface, in this way we more easily remark bugs
	   // in principle interface always divide areas with different spin.
	   for(int i = 0; i < (f->location - of->location) * a.maxcol; i++) os << of->right;; 
	 }
    }
  os << '|';
  for(int i = 0; i<  (transverse<floatt>::length - of->location) * a.maxcol; i++) os << of->right; 
  os << a.Count() << endl;

  return os;
};

 


} // namespace spins

#endif // __SPINS_H_
