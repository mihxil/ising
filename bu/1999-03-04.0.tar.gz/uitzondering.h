#ifndef __UITZONDERING_H__
#define __UITZONDERING_H__


#include <g++-2/stdexcept>
#include <string>

  class uitzondering : public exception
    { 
      string _wat;
    public:
      uitzondering(const string& what_arg){ _wat = what_arg;}  
      string wat() { return _wat;}
    };

#endif // __UITZONDERING_H__
