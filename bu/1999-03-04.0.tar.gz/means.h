
#include "ising.h"

namespace means
{
  template <class floatt, class sitetype> 
  void init(isingmodel<floatt, sitetype> * model, int n)
    {
      for(int i = 0; i < n; i++)  
	{
	  //*debug*/cout << "iteration : " << i << endl << *model;
	  model->Iteration();	
	}
    }


	// simple 3D model
	/*
	typedef float Float;
	sites::simple3D::setsizei(0, cmdl.sizex);
	sites::simple3D::setsizei(1, cmdl.sizey);
	sites::simple3D::setsizei(2, cmdl.sizez);

	isingmodel<Float, sites::simple3D>  model(&draw, cmdl.K);
	
	//model.init();
	//model.summarize();  
	//cout << model; 
	
	 model.sizes(cout) << " Ising model  at K = " << cmdl.K << "  seed = " << cmdl.seed << endl;


	 //Before we start the real calculation we want to bring the model to an equilibrium:
	 model.init(); // set all spins to known positions:
	 //for(int i= 0; i < cmdl.ntoss; i++) model.WolffIteration();


	 Float sumM2 = 0;  
	 Float sumM4 = 0;     
	 Float tsumM2 = 0; // totalsum
	 Float tsumM4 = 0;
	 Float M, M2, Q, sumQ = 0 , sumQ2 =0;
	 unsigned nup;
	 
	 
	 for(int k = 0; k < cmdl.averageQ; k++)
	   {      
	     sumM2 = 0; 
	     sumM4 = 0;
	     for(int j = 0; j < cmdl.averagei; j++)
	       {
		 //model.init(); // set all spins to one direction, we might not want to do this everytime
		 
		 // loop to reach new equilibrium
		 
		 for(int i = 0; i < cmdl.iterations; i++) model.WolffIteration();	  
		 // Magnetisation:
		 M = (Float)2 * model.nup() - model.size();
		 M2 = M*M;
		 sumM2 += M2;
		 sumM4 += M2*M2;          
	       }
	     
	     tsumM2 += sumM2;
	     tsumM4 += sumM4;
	     Q = (Float)sumM2*sumM2 / (cmdl.averagei * sumM4); 
	     sumQ  += Q;
	     sumQ2 += Q*Q;
	   }
	 
	 //cout << "   <M^2> = " << (float)sumM2/cmdl.averagei 
	 //     << "\n <M^4> = " << (float)sumM4/cmdl.averagei
	 Q  = sumQ / cmdl.averageQ; // help to calculte dQ
	 Float dQ = sqrt(sumQ2 / (cmdl.averageQ) - Q*Q); // SDn-1 
	 Float realQ = (Float)tsumM2*tsumM2 / (cmdl.averagei * cmdl.averageQ *tsumM4); 
	 cout  << "    Q  = " << realQ << " +- " << dQ << endl;
	*/





}
