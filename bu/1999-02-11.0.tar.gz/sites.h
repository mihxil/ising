// -*-C++-*-
#ifndef __SITES_H_
#define __SITES_H_

#include <string>
#include "rnd.h"

namespace sites // possible sitetypes
{
  
  // base class for sites:
class site
{
 public:
  virtual unsigned operator()() { return  0;}
  virtual string lprint() { return  "";}  
  static rnd::uniform* draw;
};


//----------------------------------------------------

// I might be nice to also make here a virtual base class.
class c1D
{
public:
  static c1D siz;
  int x;  
  c1D(int i = 0) { x = i;}
  
  int index() const { return x; };
  
  static int maxnb() { return 2;}  
  int nb(int i) const
    {
      switch(i)
	{
	case 0: return (x   - 1 + siz.x) % siz.x;
	case 1: return (x   + 1) % siz.x;
	}      
    }
};

/*
class c2D
{
public:
  static int maxx, maxy;
  int x, y;
  
  int index() const { return x + siz.x * y; }

  c2D(int i) { x =  i % maxx; y = i / maxx % maxy;}
  static int maxnb() { return 4;}  
  int nb(int i) const
    {
      switch(i)
	{
	case 0: return (x - 1 + siz.x) % siz.x +  y*siz.x;
	case 1: return (x +1) % siz.x +  y*siz.x;
	case 2: return x + ((y - 1 + siz.y) % siz.y) * siz.x;
	case 3: return x + ((y +1) % siz.y) * siz.x;
	}      
    }
};

*/
class c3D
{
public:
  static c3D siz;
  int x,y,z;

  c3D(int i = 0) { x = i % siz.x; y= i / siz.x; }
  int index() { return x*y*z;}
  static int maxnb() { return 6;}  
  int nb(int i)
    {
      switch(i)
	{
	  /*
	case 0: return (x - 1 + siz.x)%siz.x +  (y + z*siz.y) * siz.x;
	case 1: return (x + 1)%siz.x +          (y + z*siz.y) * siz.x;
	case 2: return x + ((y - 1 + siz.y)%sizey +  z*siz.y) * siz.x;
	case 3: return x + ((y +1)%siz.y          +  z*siz.y) * siz.x;
	case 4: return x + (y +          (z + 1)%siz.z*siz.y) * siz.x;
	case 5: return x + (y +  (z - 1 + siz.z)%siz.x*siz.y) * siz.x;
	  */
      }
    }
};


// This one is undoubtable less efficient, but it's handy to have it of course.
template <int n>
class cnD
{
public:
  int x[n];
  static int siz[n];

   cnD(int i = 0)     
    {
      int in = i;
      for(int j = 0; j < n; j++)
	{ 
	  x[i] = in % siz[i];
	  in /= siz[i];
	}
    } 

  operator int() const 
    { 
      int in = x[n-1]; 
      for(int i = n - 2; i >= 0; i++)
	{ 
	  in = siz[i] * in + x[i];
	} 
      return in;
    }

  static int max() 
    {
      int h = 1;
      for(int i = 0; i < n; i++) h*= siz[i];
      return h;
    }

  static int maxnb() { return 2 * n;}

  int nb(int i) const
    {
      return; 
    }
  
};


//--------------------------------------------------------

template <class coor>
class classical : public site
  /* 
     A classical n-dimensional Ising site. The type coor should have the following functions:
     
     coor(int);  index -> x,y,z 
     index();    x,y,z -> index
     maxnb();      number of neighbors
     

   */
{
protected:
  static coor siz;
  coor x;
public:
  classical(coor xx = 0)            { x = xx; }
  classical(unsigned i = 0)         { x = i; }
  static void setsize(coor xx)       { siz = xx; }
  virtual unsigned operator()()      { return x.index(); }
  static unsigned size()             { return siz.index(); }
  static unsigned maxnb()            { return coor::maxnb();}      // number of neighbors
  classical<coor> nb(unsigned i)    { return x.nb(i); }
};
    
/* ---------------------------------------------------------------------------
   
   1D 

 */

class simple1D : public classical<cnD<1> >
{
public:
  simple1D(int n) : classical<cnD<1> >(n) {}  
  static simple1D random() { return draw->idraw(max()); } // returns random site.
  
  friend ostream& operator<<(ostream&, const simple1D &); 
  
  virtual string lprint() { return x.x[0] == siz.x[0]-1 ? "\n" : "";}
};

ostream& operator<<(ostream& os, const simple1D& s)
{
 os << "(" << s.x.x[0] << ")"; 
 return os;
} 




/* --------------------------------------------------------------------
class simple2D, is an example of which the lattice-class type can use for it sizes.

The idea is that if you want to create another type of lattice, you only need to redefine 
a new type for its sites, in which you should define at least the same memberfunctions.

 */
class simple2D : public classical<c2D>
{    
 public:
  simple2D(int n) : classical<c2D>(n) {}  
  
  static simple2D max()    { return simple2D(siz.index); } // returns the largest site.
  static simple2D random() { return draw->idraw(siz.index); } // returns random site.

  friend ostream& operator<<(ostream&, const simple2D);  
  virtual string lprint()  { return x.x == siz.x-1 ? "\n" : "";}
 
};

ostream& operator<<(ostream& os, const simple2D s)
{
 os << "(" << s.x.x << "," << s.x.y << ")"; 
 return os;
}


// 3D model
// template<unsigned sizex=0, unsigned sizey=0> 
//template <unsigned n>
class simple3D : public classical<cnD<3> >
{
public:
  simple3D(int n) : classical<cnD<3> >(n) {}  

  virtual unsigned operator()()  { return x + (y +z * sizey)*sizex ;  }


  virtual simple3D  nb(unsigned i) // index of neighbor i
  {


  }
  static simple3D  max()    
    { return simple3D(sizex, sizey, sizez); } // returns the largest site.+
  static simple3D random() 
    { return draw->idraw(sizex * sizey * sizez); } // returns random site.

  friend ostream& operator<<(ostream&, const simple3D); 
  
  virtual string lprint(){ return x == sizex-1 ? (y == sizey-1 ? "\n\n" : "\n") : "";}
 
};



/* -----------------------------------------------------------------------------------------
   Transverse sites.
   One of the coordinates is a floating point number

 */
/*
template <unsigned sizex, class floatt>
class transverse1D : public simple2D<sizex>
{
  floatt y;
 public:
    
  transverse2D (unsigned xx = 0, floatt yy = 0) : simple1D<sizex>(xx) { y = yy; }
  transverse2D (simple1D<sizex> x) : simple1D<sizex>(x) { y = 0; }

  static transverse2D<sizex, floatt> random() { return transverse2D(draw->idraw(sizex), draw->draw()); }
  static transverse2D<sizex, floatt> max()    { return transverse2D(sizex, 1); } // returns the largest site.

  template <unsigned  sx, class f> 
  friend ostream& operator<<(ostream&, const transverse2D<sx,f>&);

  virtual string lprint() { return x == sizex-1 ? "\n" : "";}

  floatt gety(){ return y;}
};

template <unsigned  sizex, class floatt> 
ostream& operator<<(ostream& os, const transverse2D<sizex, floatt>& s)
{
 os << "(" << s.x << "," << s.y << ")"; 
 return os;
} 
*/

}// namespace sites
#endif // __SITES_H_
