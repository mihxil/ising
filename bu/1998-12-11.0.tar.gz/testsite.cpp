#include "sites.h"
#include <iostream>


main()
{

  sites::simple3D::setsize(10,20,30);
  sites::simple3D test (1899);

  cout << test() << "  " << test.x << "   " << test.y << "   " << test.z << endl;

  for(int i = 0; i< test.maxnb(); i++)
    {
      cout << (test.nb(i))() << "  " << test.nb(i).x << "   " << test.nb(i).y << "   " << test.nb(i).z << endl;
    }

}
