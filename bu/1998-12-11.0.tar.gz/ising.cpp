/* ------------------------------------------------------
   Ising Model 
   
   ------------------------------------------------------
*/    
//#include <iostream>
#include "ising.h"
#include "spins.h"
#include "sites.h"
#include <astack.h>
#include "cmdline.h"
#include <complex>

// 
template <class floatt, class spintype, class sitetype> 
void  isingmodel<floatt, spintype, sitetype>::summarize(ostream& os)
{
  os << sitetype::max() << " Ising model \n"
     << "Jx = " << m_Jx << "  Jy = " << m_Jy << "\n" 
     << "B = " << m_B << "\n" 
     << "number of spins up: " << nup() << "\n";

}

/* ---------------------------
   Metropolis algoritme.
   'Ising Model'
   
   zie ook: Reif, F. - Fundamentals of Statistical and Thermal Physics 
                     - McGraw-Hill 1985
*/


template <class floatt, class spintype, class sitetype> 
void isingmodel<floatt, spintype, sitetype>::MetropolisIteration()
{ 
  static unsigned i; // static to prevent repeating of declaration (more efficient, hopefully)

  // chose random site (metropolis):
  i = m_draw.idraw(sitetype::size());  

  // calculate energy difference if we would flip it:
  static floatt DeltaE;    //static to prevent realocation
    
  DeltaE = -2 * *getat(i) * ( m_Jx * getsumnb(i) - m_B );
  
  // assign new value for this spin:

  if(DeltaE < 0) // if DeltaE > 0, we do nothing
    { 
      if(m_draw.draw()>=1.0/(1+exp(+2*DeltaE))) // misschien nog niet goed.
	{ 
	  setat(i,(*getat(i)==1 ? -1 : 1)); 
	}
    }
 
  m_nit++; // number of iterations
}

/* ------------------------------------------------------------------------
   Swendsen / Wang 
   bond algoritme
   
  zie ook Phys. Rev. Letters {\bf 58} (1987) 86

*/

template <class floatt, class spintype, class sitetype> 
void isingmodel<floatt, spintype, sitetype>::SwendsenWangIteration()
{
// not yet implemented
  /*
    There used to be an implementation which was recursive, but it doesn't fit in the schema now.
    
  */

}
/* ------------------------------------------------------------------------

   Wolff algorithm

   see also Phys. Rev. Letters {\bf 62} (1989) 361
  
 */

template <class floatt, class spintype, class sitetype> 
void isingmodel<floatt, spintype, sitetype>::WolffIteration()
{
  static sitetype currentsite;
  static unsigned j;

  // chose random lattice site:  
  currentsite = sitetype::random();
  
  //flip it:
  getat(currentsite)->flip();

  //We need a stack to put positions in.
  // Astack is a fast stack type, see astack.h  
  static Astack<sitetype> thestack;

  thestack.push(currentsite); // we want to start with our start position on the stack, because it makes our loop simpler.   

   // !! Not yet fully optimized for efficiency.
  while(!thestack.empty())
    {
      currentsite = thestack.top(); thestack.pop();
      // looking at the neighbors
      for(j = 0; j < sitetype::maxnb(); j++)      
	{
	  if(!(*getat(currentsite.nb(j)) == *getat(currentsite)))
	    { 
	      // decide to add it to the stack or not:	  	      
	      if(m_draw->draw() < m_one_minus_exp) // with probability 1 - exp(-K)
		{ 
		  getat(currentsite.nb(j)) -> flip(); //  flip this neighbor
		  thestack.push(currentsite.nb(j));   //  and push it on the stack
		}
	    }
	} // for neighbors    
    } // while stack not empty
  m_nit++; // count iterations (not really necessary)
}// Wolff

/* --------------------------------------------------------------------
   Anisotropic Wolff algorithm

   It seems to me impossible to do it with the same code, so that's why I create it again 
   here..

 */

template <class floatt, class spintype, class sitetype> 
void isingmodel<floatt, spintype, sitetype>::AnisotropicWolffIteration()
{

  static sitetype i;
  //We need a stack to put positions in.
  // Astack is a fast stack type, see astack.h  
  static Astack<sitetype> thestack; // We don't want to reallocate it repeatedly 

  // chose random lattice site:  
  //i = sitetype::random();
  i = sitetype(1,0.5);
    
  // put some other interfaces on (for testing purposes)
  getat(i)->Insert(new typename spintype::interface(0.25,1));
  getat(i)->Insert(new typename spintype::interface(0.75,-1));

    // put it on the stack
  thestack.push(i);

  typename spintype::interface * smaller, * bigger;

  floatt jump;

  //Iterate until stack is empty again
  while(!thestack.empty())
    {
      // get site from stack:
      i= thestack.top(); thestack.pop();
     
      // get nearest interfaces:
      getat(i)->GetNearestInterfaces(i.gety(), &smaller, &bigger);
      
      //cout << *lower << "   " << *higher << endl;
      // draw an expontial distributed number:

      floatt ly, hy, iy;
      ly = smaller->gety();
      hy = bigger->gety();
      iy = i.gety();

      typename spintype::interface::rightspin r;
      r = smaller->getspin();
      
      m_draw->setmean(m_exp_kx);
      //lower side:
      jump = 0.1; // (*m_draw)();     
      // getat(i)->DumpTree(cout);  // debug
      if(iy - jump <= ly) // jumped over interface, remove interface
	{	  
          getat(i)->DeleteSmaller();
	}
      else                // not jumped over it, add one.
	{
	  getat(i)->Insert(new typename  spintype::interface(iy-jump, -r));
	  ly = iy - jump;
	}
      // getat(i)->DumpTree(cout);  // debug

      //higher side side (same things:
      jump = 0.1; // new random number
      if(iy + jump >= hy) // jumped over nearest interface
	{
	  getat(i)->DeleteBigger();
	}
      else                //
	{
	  getat(i)->Insert(new typename spintype::interface(iy + jump, r));
	  hy = iy + jump;
	}
      //getat(i)->DumpTree(cout);  // debug

      // We now know in which area we should try to add interfaces in the 
      // other directions
      m_draw->setmean(0.2);
      for(unsigned j = 0; j < sitetype::maxnb(); j++) 
	{
	  for(floatt ny = ly + (*m_draw)(); ny< hy; ny+= (*m_draw)())
	    {	
	      cout << getat(i.nb(j))->at(ny);
	      getat(i.nb(j))->Insert(new typename spintype::interface(ny,0));

	    }
	}
      //getat(i)->DumpTree(cout);  // debug
            
    } 
  //Wolff iteration completed
  m_nit++;
  return;
}//Anisotropic Wolff

/* -------------------------------------------------------------------	\
   MAIN									\

*/

int main(int argc, char *argv[])
{
    typedef double floattt;  
    c_cmdln cmdl(argc, argv, // reads the commandline parameters in 'cmdl'.
    "Ising programma -- Michiel Meeuwissen, december 1998"); 


    // We only use one random-generator.
    // The several classes all have a pointer to it. 
    // further, we make sure that the seed is always negative...
    rnd::exponential draw(- abs(cmdl.seed) -1 );

    // copy a pointer to this random number generator to the classes
    spins::spin::draw = &draw;
    sites::site::draw = &draw;

    // How to write floating point numbers:
    cout.setf(ios::fixed, ios::floatfield); // default precision 6 digits
    // Stroustrup sais ios -> ios_base, but this isn't recognized by the current state of this compiler.

    // several examples (comment only one out)
    // isingmodel<float, spins::updown, sites::simple1D<15> > model(&draw, 0.001);
    // isingmodel<float, spins::anisotropic<float>, sites::anisotropic<15,float> > model(&draw, 0.001);

    // set the size before we define our model (otherwise runtime error, because the model declares memory)
    sites::simple3D::setsize(cmdl.sizex,cmdl.sizey,cmdl.sizez);
    // define the model:
    isingmodel<floattt, spins::updown, sites::simple3D >  model(&draw, cmdl.K);
  
    //model.init();
    //model.summarize();  
    //cout << model;

    cout << sites::simple3D::max() << " Ising model  at K = " << cmdl.K << "  seed = " << cmdl.seed << endl;


  //Before we start the real calculation we want to bring the model to an equilibrium:
  model.init(); // set all spins to known positions:
  //for(int i= 0; i < cmdl.ntoss; i++) model.WolffIteration();


  floattt sumM2 = 0;  
  floattt sumM4 = 0;     
  floattt tsumM2 = 0; // totalsum
  floattt tsumM4 = 0;
  floattt M, M2, Q, sumQ = 0 , sumQ2 =0;
  unsigned nup;
     
 
  for(int k = 0; k < cmdl.averageQ; k++)
    {      
      sumM2 = 0; 
      sumM4 = 0;
      for(int j = 0; j < cmdl.averagei; j++)
	{
	  //model.init(); // set all spins to one direction, we might not want to do this everytime
	  
	  // loop to reach new equilibrium
	  for(int i = 0; i < cmdl.iterations; i++) model.WolffIteration();	  
	  // Magnetisation:
	  M = (floattt)2 * model.nup() - model.size();
	  M2 = M*M;
	  sumM2 += M2;
	  sumM4 += M2*M2;          
	}

      tsumM2 += sumM2;
      tsumM4 += sumM4;
      Q = (floattt)sumM2*sumM2 / (cmdl.averagei * sumM4); 
      sumQ  += Q;
      sumQ2 += Q*Q;
    }

  //cout << "   <M^2> = " << (float)sumM2/cmdl.averagei 
  //     << "\n <M^4> = " << (float)sumM4/cmdl.averagei
  Q  = sumQ / cmdl.averageQ; // help to calculte dQ
  floattt dQ = sqrt(sumQ2 / (cmdl.averageQ) - Q*Q); // SDn-1 
  floattt realQ = (floattt)tsumM2*tsumM2 / (cmdl.averagei * cmdl.averageQ *tsumM4); 
  cout  << "    Q  = " << realQ << " +- " << dQ << endl;

  //model.AnisotropicWolffIteration();

  //model.summarize();
  //cout << model;
  return 0;
}
