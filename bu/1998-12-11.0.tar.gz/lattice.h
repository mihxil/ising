#ifndef __LATTICE_H_
#define __LATTICE_H_

#include <cstddef>
#include <iostream>
#include "rnd.h"


template <class spin, class site>
class lattice
{
  // data members:
 private: 
  spin * r;

 public:
  //constructor:
  lattice();

  //member functions
  void  setat(site& s, spin * v)    { r[s()] = v;  }
  void  setat(unsigned i , spin * v){ r[i]   = v;  }
  spin * getat(site s) const       { return &r[s()];}  // returns pointer, such that we can change it in one operation and we don't have to copy it.
  //spin* getat(unsigned i) const   { return &r[i];  }
  typename spin::spinsum getsumnb(unsigned i) const 
    {
      typename spin::spinsum hulps(0);
      for(int j=0; j<site::maxnb(); j++)
	{
	  hulps += r[site(i).nb(j)];
	}
      return hulps;
    }
  void  init();
  void  init(spin);
  void  print(ostream& os = cout) const;
  template <class s, class st> friend ostream& operator<<(ostream&, const lattice<s,st>);
  typename spin::spinsum  nup() const;
  unsigned size() const { return site::size();}

};

/*
  Implementation of this template-class probably should be in this header file,
  because the compiler cannot know for which types it should generate code.

  These _are not_ real implementations, of course. Because they are only compiled if 
   necessary.


 */


template <class spin, class site> lattice<spin,site>::lattice()
{
 // size =  site::size();
 // sizes = N;
 r = new spin[site::size()];
}

template <class spin, class site> void lattice<spin, site>::init()
// initialiseert het rooster r met willekeurige waarden.
{
  for(int i=0; i<site::size(); i++) getat(i)->makerandom();
  return;  
}

template <class spin, class site> void lattice<spin, site>::init(spin v)
// initialiseert het rooster r met v
{
  for(int i=0; i<site::size(); i++) setat(i,v);
  return;
}

template <class spin, class site> 
void lattice<spin, site>::print(ostream& os) const
{
  for(int i=0; i<site::size(); i++) os << *getat(i)  << site(i).lprint();     
  return;
}

template <class spin, class site> 
ostream& operator<<(ostream& os, const lattice<spin, site> l)
{
 l.print(os); 
 return os;
}
 
template <class spin, class site> 
typename spin::spinsum  lattice<spin, site>::nup() const
{ 
  typename spin::spinsum hulp=0;
  for(int i=0; i<site::size(); i++) hulp+= (getat(i)->upvalue());
  return hulp;
}

#endif //__LATTICE_H_
