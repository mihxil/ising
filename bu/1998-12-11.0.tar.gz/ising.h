
#include "lattice.h"
#include "rnd.h"

/*
    remarks
    the isingmodel class is now totally based on templates
    advantages en disadvantages I can think of:
    - It's less flexible. I cannot determine the size of the lattice at run-time.
    - It might be faster, because the sizes are compiled in, so we can hope that the compiler
      already calculates what it can (if true, must be possible to imitate)
       
*/

template <class floatt, class spintype, class sitetype> 
class isingmodel : public lattice<spintype, sitetype>
{
 
  floatt           m_K, m_one_minus_exp;
  //  m_Kx, m_Ky, m_B, m_one_minus_exp, m_beta;
  unsigned         m_nit; // number of iterations
  rnd::exponential * m_draw; 

  //void (m_iteration)(); // function used for iterations.  , neat idea, but it's going to give to much trouble.
      
  // random-number generator;
  //  'exponential' but you also can draw uniform numbers from it.
  // draw()   : 0..1
  // idraw(n) : 0..n (integer)
  // ()       : exponential
  

 public:
  // constructor:
  isingmodel(rnd::exponential * d, floatt K = 1) : lattice<spintype, sitetype> () 
    {
      m_draw = d;
      /*
      m_B = 0;
      m_Kx = Kx;
      m_Ky = 0;
      */
      m_K = K;
      m_nit = 0;
      m_one_minus_exp = 1 - exp(- 2*m_K);
      //m_exp_kx = 20;
      
      //      m_iteration = it; // default
    }
  
  void MetropolisIteration();         
  void SwendsenWangIteration();
  void WolffIteration();
  void AnisotropicWolffIteration();

  //  void Iterate() { m_iteration(); } // for the time being I resign about this.

  void     summarize(ostream& os = cout);
  unsigned getnit() { return m_nit;}
  
};

