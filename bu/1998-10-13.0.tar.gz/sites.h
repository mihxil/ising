#ifndef __SITES_H_
#define __SITES_H_

#include <string>
#include "rnd.h"

namespace sites // possible sitetypes
{

// base class for sites:
class site
{

 public:
  virtual unsigned operator()() { return  0;}
  virtual string lprint() { return  "";}
  static rnd::uniform* draw;

  
};

/* --------------------------------------------------------------------
class simple2D, is an example of which the lattice-class type can use for it sizes.

The idea is that if you want to create another type of lattice, you only need to redefine 
a new type for its sites, in which you should define at least the same memberfunctions.

 */
template<unsigned sizex=0, unsigned sizey=0> 
class simple2D : public site
{
  unsigned x,y; // may be it's quicker not to store x, y but x + y*sizex
 public:
  simple2D(unsigned xx, unsigned yy) { x = xx; y = yy;}
  simple2D(unsigned i = 0) { x = i % sizex; y = i / sizex; }
  virtual unsigned operator()()  { return x + y*sizex; }
  static unsigned size() { return sizex * sizey; }
  static unsigned maxnb(){ return 4;}           // number of neighbors
  virtual simple2D<sizex, sizey> nb(unsigned i) // index of neighbor i
  {
    switch(i)
    {
      case 0: return (x - 1 + sizex) % sizex +  y*sizex;
      case 1: return (x +1) % sizex +  y*sizex;
      case 2: return x + ((y - 1 + sizey) % sizey) * sizex;
      case 3: return x + ((y +1) % sizey) * sizex;
    }

  }
  static simple2D<sizex, sizey> max()    
    { return simple2D(sizex, sizey); } // returns the largest site.
  static simple2D<sizex, sizey> random() 
    { return draw->idraw(sizex * sizey); } // returns random site.

  template <unsigned  sx, unsigned sy> friend ostream& operator<<(ostream&, const simple2D<sx,sy>); 
  
  virtual string lprint() { return x == sizex-1 ? "\n" : "";}
 
};

template <unsigned  sizex, unsigned sizey> ostream& operator<<(ostream& os, const simple2D<sizex,sizey> s)
{
 os << "(" << s.x << "," << s.y << ")"; 
 return os;
}

/* ---------------------------------------------------------------------------
   
   1D 

 */

template <unsigned sizex>
class simple1D : public site
{
 protected:
  unsigned x;
  // Trees may not be copied, we ensure it like this (only a the pointer will be copied) in the 
  // default copy-constructor (take care!)
 
 public:
  simple1D(unsigned xx = 0) { x = xx;}
  
  virtual unsigned operator()()  { return x;     }
  static unsigned size() { return sizex; }
  static unsigned maxnb(){ return 2;}      // number of neighbors
  virtual simple1D<sizex> nb(unsigned i)   // index of neighbor i
  {
    switch(i)
    {
      case 0: return (x - 1 + sizex) % sizex;
      case 1: return (x +1) % sizex;
    }
  }

  static simple1D<sizex> max()    { return simple1D(sizex); } // returns the largest site.
  static simple1D<sizex> random() { return draw->idraw(sizex); } // returns random site.
 
  template <unsigned  sx> 
  friend ostream& operator<<(ostream&, const simple1D<sx>&); 

  virtual string lprint() { return x == sizex-1 ? "\n" : "";}
};

template <unsigned  sizex> 
ostream& operator<<(ostream& os, const simple1D<sizex>& s)
{
 os << "(" << s.x << ")"; 
 return os;
} 

/* -----------------------------------------------------------------------------------------
   Anisotropic sites.
   One of the coordinates is a floating point number

 */

template <unsigned sizex, class floatt>
class anisotropic : public simple1D<sizex>
{
  floatt y;
 public:
    
  anisotropic (unsigned xx = 0, floatt yy = 0) : simple1D<sizex>(xx) { y = yy; }

  static anisotropic<sizex, floatt> random() { return anisotropic(draw->idraw(sizex), draw->draw()); }
  static anisotropic<sizex, floatt> max()    { return anisotropic(sizex, 1); } // returns the largest site.

  template <unsigned  sx, class f> 
  friend ostream& operator<<(ostream&, const anisotropic<sx,f>&); 

  virtual string lprint() { return x == sizex-1 ? "\n" : "";}

  floatt gety(){ return y;}
};

template <unsigned  sizex, class floatt> 
ostream& operator<<(ostream& os, const anisotropic<sizex, floatt>& s)
{
 os << "(" << s.x << "," << s.y << ")"; 
 return os;
} 


}// namespace sites
#endif // __SITES_H_
