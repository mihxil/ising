
#include "spins.h"

namespace spins
{
ostream& operator<<(ostream& os, const updown s)
{	  
  os << ((s.value == -1) ? "-" : ((s.value == +1) ? "+" : "*") ); 
  return os;
}

rnd::uniform* spin::draw = NULL;

}
