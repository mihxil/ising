#ifndef __SPINTYPE_H_
#define __SPINTYPE_H_

// MM 5 october 1998

#include <iostream.h>
#include <rnd.h>
#include <avl.h>
#include <avl.cpp> // For the template instantiations.
#include "sites.h"

/* In this file the classes for an actual system under study are described.

   A system is described by two classes, one which describes the 'spin' on a
   lattice site, and one which describes the properties of such a site.


 */

namespace spins // possible spintypes
{

class spin
{
 public:  
  static rnd::uniform*  draw;
  typedef int spinsum;  // this is the type of the number of summed spins.

  typedef spin* attype;

  virtual attype at(sites::site s) { return this; } 
  // virtual spinsum upvalue() const { return 0;}
  
};
 

class updown : public spin
{
 private:
  signed value;
 public:
  // constructor
  updown(signed i=1) { value = i; }

  // how it counts
  spinsum upvalue() const { return value == 1 ? 1 : 0; }

  // how to flip it  
  updown*  flip() { value = -value; /*can this be more efficient*/ return this;}

  // how to convert this spin to a float:
  //operator float() const{ return (float)value; }

  // how to make a random value:
  static updown random() { return ( draw->idraw(2) == 0) ? -1 : 1;}
  
  // - operator
  //updown   operator-() { return -value; } 
  //void     operator+=(updown s) { value +=s.value;}

  // how to print this spin:
  friend ostream& operator<<(ostream&, const updown);

  //signed  getvalue() { return value;}
};
/* --------------------------------------------------------------------------------


 */
template <class floatt>
class anisotropic;

template <class floatt>
class interfacetype
{
  floatt location;   // where it is located

  typedef updown rightspin;
  rightspin    right;          // what spin is right from this interface
 public:
  interfacetype( int r, floatt loc) { location = loc; right = r; }
  // a few operators have to be overloaded for this type (it must be comparable to fit in a avl::Tree)
  template <class f> 
  friend ostream& operator<<(ostream&, const interfacetype<f>);

  bool operator<(const interfacetype<floatt> & i) const 
    {
      return location < i.location; 
    } 
  bool operator==(const interfacetype<floatt> & i) const 
    { 
      return location == i.location; 
    }
  
  template <class f>
  friend ostream& operator<<(ostream&, const anisotropic<f>& );
  
  floatt gety() { return location; }

  friend class anisotropic<floatt>;
};

template<class floatt>
ostream& operator<<(ostream& os , const interfacetype<floatt> a)
{
os << a.location;
return os;
}
//------------------------------------------------------

template <class floatt>
class anisotropic : public spin
  {
    typedef floatt spinsum; // the number of spins up now of course can be a floatt.
    typedef interfacetype<floatt> interface;
    typedef typename interface::rightspin attype;

    avl::Tree<interface > * values; 

  public:
    attype at(floatt y) 
      { 
	interface* l, * h;
	values->SSearch(interface(0,y), &l, &h);
	return l->right;	
     } 
    void  GetNearestInterfaces(float y, interface ** l, interface **h)
      {
	values->SSearch(interface(0,y), l, h);
	return;
      }
    void  Insert(interface * i)
      {
	values->Insert(i);
	return;
      }
    void Delete(interface **i)
      {
      }

  private:
    // forbid copying:
    anisotropic(const anisotropic<floatt>& a);
  public:
    anisotropic() : values(NULL)
      {
	//cout << "anisotropic 1\n";
      }
    anisotropic(floatt i) 
      { 
	//cout << "anisotropic 2\n";
	values = new avl::Tree<interfacetype<floatt> >;  
	values->Insert(new interfacetype<floatt>(interface(i,0)));	
      }
    ~anisotropic()
      { 
        //cout << "~anisotropic\n";
	// if(values) { delete values; values = NULL; }
      }


    static const int maxcol = 120;

    void  operator+=(anisotropic<floatt> s) { }

    spinsum upvalue() const 
      {
	spinsum hulp = 0;
	interface * f;
	interface * of;
        typename interface::rightspin cur;
	
	f = values->Lowest();
	while(f)
	  {
	    of = f;
	    cur = of->right;
	    f = values->Next();
	    if(f && cur.upvalue()) hulp += f->location - of->location;
	  }
	if(cur.upvalue()) hulp+= 1.0 - of->location;
        
	return hulp; 
      }// returns part which is up.
    //floatt getvalue() { return 1;}

    static floatt random() { return (draw->idraw(2) == 0) ? -1 : 1;}

    template <class f>
    friend ostream& operator<<(ostream&, const anisotropic<f>&);
  };

template<class floatt>
ostream& operator<<(ostream& os , const anisotropic<floatt>& a)
{
  //const int maxcol = 150;
  int column = 0;

  //  os << a.upvalue();
  typename anisotropic<floatt>::interface * f;
  typename anisotropic<floatt>::interface * of;
  //  typename anisotropic<floatt>::spintype::rightspin cur;

  f = a.values->Lowest();    
  while(f)
    {      
      of = f;
      //cur = of->right;
      f = a.values->Next();
      if(f) for(int i=0; i<  (f->location - of->location) * a.maxcol; i++) os << of->right;; 
    }
  for(int i=0; i<  (1.0 - of->location) * a.maxcol; i++) os << of->right; 
  os << endl;

  return os;
};

 


} // namespace spins

#endif // __SPINTYPE_H_
