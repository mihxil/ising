
#include "lattice.h"
#include "rnd.h"

/*
    remarks
    the isingmodel class is now totally based on templates
    advantages en disadvantages I can think of:
    - It's less flexible. I cannot determine the size of the lattice at run-time.
    - It might be faster, because the sizes are compiled in, so we can hope that the compiler
      already calculates what it can (if true, must be possible to imitate)
      
      
*/

template <class floatt, class spintype, class sitetype> 
class isingmodel : public lattice<spintype, sitetype>
{
 
  floatt           m_J, m_Jx, m_Jy, m_B, m_one_minus_exp, m_beta, m_exp_kx;
  unsigned         m_nit; // number of iterations
  rnd::exponential * m_draw; 
      
  // random-number generator;
  //  'exponential' but you also can draw uniform numbers from it.
  // draw()   : 0..1
  // idraw(n) : 0..n (integer)
  // ()       : exponential
  

 public:
  // constructor:
  isingmodel(rnd::exponential * d, floatt Jx = 1, floatt Jy = 1) : lattice<spintype, sitetype> () 
    {
      m_draw = d;
      m_B = 0;
      m_Jx = Jx;
      m_Jy = 0;
      m_J = m_Jx;
      m_nit = 0;
      m_one_minus_exp = 1 - exp(-m_J);
      m_exp_kx = 20;
      

    }

  void MetropolisIteration();         
  void SwendsenWangIteration();
  void WolffIteration();
  void AnisotropicWolffIteration();

  void     summarize(ostream& os = cout);
  unsigned getnit() { return m_nit;}
  
};

