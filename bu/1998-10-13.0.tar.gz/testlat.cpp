

#include "lattice.h"
#include <iostream>
#include "rnd.h"


class spintype
{
 private:
  unsigned char value;
 public:
  spintype(unsigned i=0) { value = i; };
  friend ostream& operator<<(ostream&, const spintype);
};

ostream& operator<<(ostream& os, const spintype s)
{	  
  os << (s.value == 0 ? "0" : "1"); 
  return os;
}

main()
{
  /*
  lattice<spintype> l;
  l.init();
  cout << l;
  */
  unsigned x[100];
  int i;
  
  for(i = 0; i<100; i++) x[i] = 0;

  rnd::exponential draw(30);
  
  
  for(i = 0; i< 500000; i++) x[ (int)(draw()/10) % 100]++;
  
  for(i = 0; i<100; i++) cout << i << "  " << x[i] << "\n";


  double ** m;

  m = new double[5][5];
  

}
