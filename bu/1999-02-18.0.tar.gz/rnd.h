
#ifndef __RND_H_
#define __RND_H_

#include <cstdlib>
#include "math.h"
#include <iostream>

/*

  Here I will collect the random number generators.


 */



namespace rnd
{
  long pow(int a, int b);

  class baseuniform
    {
      const static double EPS = 1.2e-7;
      const static double RNMX= 1.0-EPS;
      const static long   IM1 = 2147483563;// maximum number of the randomnumber generator
      const static double AM  = 1.0/IM1;
      
    public: 
      virtual long idraw() = 0;    
      /*
      inline long idraw() 
	{
	  return iidraw();
	}
      */
      unsigned mdraw(unsigned max)
	{
	  return idraw()% max ;
	}
      
      double draw()
	{
	  
	  double temp;
	  if (( temp = ((AM*idraw()+1)/2))  > RNMX) return RNMX;
	  else return temp;	  	  	  
	  
	  //return (AM*idraw()+1)/2;
	}
      double operator()() { return draw(); }

    };

  // a probably not too good random-number generator (Stroustrup)
  class uniformbad
    {
      unsigned long randx;
    public:
      uniformbad(long s=0){ randx = s;}
      void seed(long s) { randx = s;}
      int abs(int x) { return x&0x7fffffff;}
      static double max() { return 2147483648.0; }
      int draw() { return randx = randx*1103515245 + 12345;}
      double fdraw(){ return abs(draw())/max();}
      int operator()(){ return abs(draw());}
    };
  
  class uniform : public baseuniform
    {
      const static long   IM1 = 2147483563;// maximum number of the randomnumber generator
      const static double AM  = 1.0/IM1;

      const static long mult = 32781;
      const static long mod2 = 2796203;
      const static long mul2 = 125;
      const static long len1 = 9689;
      const static long ifd1 = 471;
      const static long len2 = 127;
      const static long ifd2 = 30;
      
      long ir1[len1];
      long ir2[len2];
      long inxt1[len1];
      long inxt2[len2];
      
      long ipnt1, ipnf1;
      long ipnt2, ipnf2;

      long seed; // remember seed
      
    public:
      uniform(long iseed = -1)
	{
	  seed = iseed;

	  long i, k, k1;

	  /// look out here!!!!
	  k = pow(3, 18) + 2 * iseed;   
	  k1 =  1313131 * iseed;
	  k1 =  k1 - (k1 / mod2) * mod2;

	  for(i = 0; i < len1; i++)
	    {
	      k =   k  * mult;
	      k1 =  k1 * mul2;
	      k1 =  k1 - (k1 / mod2) * mod2;
	      ir1[i] = k + k1 * 8193;
	    }
	  for(i = 0; i < len2; i++)
	    {
	      k = k  * mult;
	      k1 =  k1 * mul2;
	      k1 =  k1 - (k1 / mod2) * mod2;
	      ir2[i] = k + k1 * 4099;
	    }	  
	  for(i = 0; i < len1; i++)
	    {
	      inxt1[i] = i + 1;
	    }
     
	  inxt1[len1 - 1] = 0;
	  ipnt1       = 0;
	  ipnf1       = ifd1;

	  for(i = 0; i < len2; i++)
	    {
	      inxt2[i] = i + 1;
	    }
	  
	  inxt2[len2 - 1] = 0;
	  ipnt2       = 0;
	  ipnf2       = ifd2; 
	  return;

	}
      long idraw()  //draws an integer
	{
	  //^ exclusive or operations:

	  long h = ir1[ipnt1] ^ ir1[ipnf1];;

	  ir1[ipnt1] = h;
	  ipnt1 = inxt1[ipnt1];
	  ipnf1 = inxt1[ipnf1];            
	  
	  h^= (ir2[ipnt2] = ir2[ipnt2] ^ ir2[ipnf2]); // might be a little quicker like this? 
	  //	  h ^= ir2[ipnt2];
	  ipnt2 = inxt2[ipnt2];
	  ipnf2 = inxt2[ipnf2];

	  return h;
	}

    };

  // The one recommended by NR (ran2), has a period of 2^18, which is long, but eventually probably not enough
  // Use a negative seed!!! Otherwise it will not work.
  class uniformNR : public baseuniform
    {
      const static long   IM1 = 2147483563;
      const static long   IM2 = 2147483399;
      const static double AM  = 1.0/IM1;
      const static long   IMM1= IM1 - 1;
      const static long   IA1 = 40014;
      const static long   IA2 = 40692;
      const static long   IQ1 = 53668;
      const static long   IQ2 = 52774;
      const static long   IR1 = 12211;
      const static long   IR2 = 3791;
      const static int    NTAB= 32;
      const static long   NDIV= 1 + IMM1/NTAB;


      long idum; 
      long idum2;
      long iy;
      long iv[NTAB];
    public:
      long seed;// remember the seed;

      uniformNR(long s=-1) { seed = s; idum = s; idum2 = 123456789; iy=0; }

      long idraw()  //draws an integer
	{
	  int j; long k;

	  if(idum <= 0)
	    {
	      if(-idum < 1) idum = 1;
	      else idum = -idum;
	      idum2 = idum;
	      for (j= NTAB +7; j>=0; j--)
		{
		  k = idum /IQ1;
		  idum = IA1 * (idum - k* IQ1) - k*IR1;
		  if (idum < 0) idum += IM1;
		  if (j< NTAB) iv[j] = idum;
		}
	      iy = iv[0];	      
	    }
	  k= idum / IQ1;
          idum  = IA1 * (idum -  k * IQ1) - k * IR1;
	  if(idum < 0) idum += IM1;
	  k = idum2 / IQ2;	  
	  idum2 = IA2 * (idum2 - k * IQ2) - k * IR2;
	  if(idum2 < 0) idum2 += IM2;
	  j = iy/NDIV;
	  iy = iv[j] - idum2;
	  iv[j] = idum;
	  if(iy < 1 ) iy += IMM1;
	  return iy;
	}

      // Probable estas bona ideo ankaux transpreni la operatorojn >> kaj << 
      // por ke ni povu uzi ilin kiam ni volas eldangxerigi la staton de la 
      // uzanta programo (ni povus suficxe facile surdiskigi la staton kaj reensxuti gxin).
         

    };

  // how to make a exponention distribution out of a uniform one
  // This distribution we need e.g. in the anisotropic Wolf algorithme

  class exponential: public uniform
    {
      double mean;
    public:
      exponential(long seed=-1, double m = 10) : uniform(seed) { mean = m;}
      double operator()(){ return (double)(-mean*log(1.0-draw())+.5); }
      
      void  setmean(double m) { mean = m; }
    };


  //const unsigned hrandmax = RAND_MAX /2;
  //exponential draw =0 ;

  // geeft een random getal van 0 tot en met n;
  unsigned rndom(unsigned n);
};



#endif // __RND_H_
